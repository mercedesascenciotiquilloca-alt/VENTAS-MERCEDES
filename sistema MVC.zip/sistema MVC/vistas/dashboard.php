
<?php
require_once __DIR__ . '/../config/Conexion.php';

$conexion = (new Conexion())->conectar();

// =============================================
// VARIABLES DEL DASHBOARD
// =============================================

$articulos = 0;
$categorias = 0;
$stock = 0;
$ventasHoy = 0;
$comprasHoy = 0;

$stockBajo = [];
$actividades = [];
$ventasSemana = [];
$comprasSemana = [];
$errorDashboard = '';

try {

    // =============================================
    // RESUMEN GENERAL
    // =============================================

    $articulos = (int)$conexion->query("
        SELECT COUNT(*)
        FROM articulos
        WHERE estado = 'Activo'
    ")->fetchColumn();

    $categorias = (int)$conexion->query("
        SELECT COUNT(*)
        FROM categorias
        WHERE estado = 'Activo'
    ")->fetchColumn();

    $stock = (int)$conexion->query("
        SELECT COALESCE(SUM(stock), 0)
        FROM variantes_articulo
    ")->fetchColumn();

    $ventasHoy = (float)$conexion->query("
        SELECT COALESCE(SUM(total), 0)
        FROM ventas
        WHERE estado = 'Registrada'
        AND DATE(fecha_venta) = CURDATE()
    ")->fetchColumn();

    $comprasHoy = (float)$conexion->query("
        SELECT COALESCE(SUM(total), 0)
        FROM compras
        WHERE estado = 'Registrada'
        AND DATE(fecha_compra) = CURDATE()
    ")->fetchColumn();


    // =============================================
    // PRODUCTOS CON STOCK BAJO
    // =============================================

    $consultaStock = $conexion->query("
        SELECT
            a.nombre,
            a.codigo,
            COALESCE(SUM(v.stock), 0) AS stock
        FROM articulos a
        LEFT JOIN variantes_articulo v
            ON v.articulo_id = a.id
        WHERE a.estado = 'Activo'
        GROUP BY a.id, a.nombre, a.codigo
        HAVING COALESCE(SUM(v.stock), 0) <= 5
        ORDER BY stock ASC
        LIMIT 6
    ");

    $stockBajo = $consultaStock->fetchAll(PDO::FETCH_ASSOC);


    // =============================================
    // ÚLTIMAS COMPRAS Y VENTAS
    // =============================================

    $consultaActividad = $conexion->query("
        SELECT tipo, comprobante, fecha, total
        FROM (

            SELECT
                'Venta' AS tipo,
                comprobante,
                fecha_venta AS fecha,
                total
            FROM ventas
            WHERE estado = 'Registrada'

            UNION ALL

            SELECT
                'Compra' AS tipo,
                comprobante,
                fecha_compra AS fecha,
                total
            FROM compras
            WHERE estado = 'Registrada'

        ) AS movimientos
        ORDER BY fecha DESC
        LIMIT 5
    ");

    $actividades = $consultaActividad->fetchAll(PDO::FETCH_ASSOC);


    // =============================================
    // VENTAS DE LOS ÚLTIMOS SIETE DÍAS
    // =============================================

    $consultaSemana = $conexion->query("
        SELECT
            DATE(fecha_venta) AS dia,
            SUM(total) AS total
        FROM ventas
        WHERE estado = 'Registrada'
        AND fecha_venta >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY DATE(fecha_venta)
        ORDER BY dia ASC
    ");

    $datosSemana = $consultaSemana->fetchAll(PDO::FETCH_ASSOC);


    // =============================================
    // COMPRAS DE LOS ÚLTIMOS SIETE DÍAS
    // =============================================

    $consultaComprasSemana = $conexion->query("
        SELECT
            DATE(fecha_compra) AS dia,
            SUM(total) AS total
        FROM compras
        WHERE estado = 'Registrada'
        AND fecha_compra >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY DATE(fecha_compra)
        ORDER BY dia ASC
    ");

    $datosComprasSemana = $consultaComprasSemana->fetchAll(PDO::FETCH_ASSOC);


    // =============================================
    // ORGANIZAR DATOS PARA EL GRÁFICO
    // =============================================

    $ventasPorDia = [];

    foreach ($datosSemana as $dato) {
        $ventasPorDia[$dato['dia']] = (float)$dato['total'];
    }

    $comprasPorDia = [];

    foreach ($datosComprasSemana as $dato) {
        $comprasPorDia[$dato['dia']] = (float)$dato['total'];
    }

    for ($i = 6; $i >= 0; $i--) {

        $dia = date('Y-m-d', strtotime("-$i days"));

        $etiquetaDia = date('d/m', strtotime($dia));

        $ventasSemana[] = [
            'dia' => $etiquetaDia,
            'total' => $ventasPorDia[$dia] ?? 0
        ];

        $comprasSemana[] = [
            'dia' => $etiquetaDia,
            'total' => $comprasPorDia[$dia] ?? 0
        ];
    }

} catch (Throwable $e) {

    error_log("Error Dashboard: " . $e->getMessage());

    $errorDashboard = "No se pudo cargar toda la información.";
}

?>

<?php require 'header.php'; ?>


<style>

/* =============================================
   ESTILOS GENERALES
============================================= */

.dashboard-mercy {
    padding: 25px;
    background: #FFF7FA;
    min-height: calc(100vh - 100px);
    color: #65475A;
    width: 100%;
    box-sizing: border-box;
}

.dashboard-mercy * {
    box-sizing: border-box;
}


/* =============================================
   BIENVENIDA
============================================= */

.mercy-banner {
    position: relative;
    overflow: hidden;
    background: linear-gradient(
        120deg,
        #C94F88,
        #E78FB8,
        #F3B8CE
    );
    padding: 32px;
    border-radius: 22px;
    color: white;
    margin-bottom: 27px;
    box-shadow: 0 10px 25px rgba(190,76,128,.17);
}

.mercy-banner:after {
    content: "♡";
    position: absolute;
    right: 35px;
    top: -55px;
    font-size: 190px;
    color: rgba(255,255,255,.12);
    pointer-events: none;
}

.mercy-banner h1 {
    color: white;
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 12px;
}

.mercy-banner p {
    color: #FFF5FA;
    font-size: 14px;
    margin: 0;
}

.mercy-banner-info {
    text-align: right;
    position: relative;
    z-index: 2;
    padding-top: 8px;
}

.mercy-banner-info strong {
    font-size: 17px;
}

.mercy-status {
    display: inline-block;
    background: rgba(255,255,255,.22);
    padding: 8px 14px;
    border-radius: 30px;
    margin-top: 12px;
    font-size: 12px;
}


/* =============================================
   TITULOS DE SECCIÓN
============================================= */

.mercy-section {
    margin: 30px 0 18px;
}

.mercy-section h3 {
    color: #A63D73;
    font-size: 20px;
    font-weight: 800;
    margin: 0;
}

.mercy-section p {
    color: #A58A99;
    font-size: 13px;
    margin: 5px 0 0;
}


/* =============================================
   TARJETAS DE ESTADÍSTICAS
============================================= */

.mercy-stat {
    position: relative;
    background: white;
    border: 1px solid #F2DFE8;
    border-radius: 17px;
    padding: 20px;
    min-height: 137px;
    margin-bottom: 20px;
    box-shadow: 0 5px 18px rgba(170,85,125,.06);
    transition: .25s;
}

.mercy-stat:hover {
    transform: translateY(-4px);
    box-shadow: 0 9px 22px rgba(170,85,125,.12);
}

.mercy-stat-icon {
    width: 49px;
    height: 49px;
    float: right;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
}

.icon-rosa {
    background: #FCE4EF;
    color: #C34F87;
}

.icon-lila {
    background: #EFE7FA;
    color: #8965B5;
}

.icon-verde {
    background: #E3F5EC;
    color: #4CA77D;
}

.icon-dorado {
    background: #FFF1DA;
    color: #C18C36;
}

.mercy-stat small {
    color: #9D8492;
    font-weight: 600;
    font-size: 12px;
}

.mercy-stat h2 {
    color: #78445F;
    font-size: 27px;
    font-weight: 800;
    margin: 15px 0 0;
}


/* =============================================
   ACCESOS RÁPIDOS
============================================= */

.mercy-access {
    display: block;
    background: white;
    border: 1px solid #F0DCE6;
    border-radius: 17px;
    padding: 23px 12px;
    text-align: center;
    margin-bottom: 20px;
    text-decoration: none !important;
    transition: all .25s ease;
    box-shadow: 0 4px 15px rgba(170,85,125,.05);
}

.mercy-access:hover {
    transform: translateY(-5px);
    border-color: #E5A0BF;
    box-shadow: 0 10px 22px rgba(190,76,128,.12);
}

.mercy-access-icon {
    width: 57px;
    height: 57px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 14px;
    border-radius: 17px;
    background: #FCE8F1;
    color: #C34F87;
    font-size: 23px;
}

.mercy-access h4 {
    color: #854764;
    font-weight: 800;
    font-size: 14px;
    margin: 0 0 7px;
}

.mercy-access p {
    color: #A58A99;
    font-size: 12px;
    margin: 0;
}


/* =============================================
   PANELES
============================================= */

.mercy-panel {
    background: white;
    border: 1px solid #F0DCE6;
    border-radius: 17px;
    margin-bottom: 22px;
    box-shadow: 0 5px 18px rgba(170,85,125,.06);
    overflow: hidden;
}

.mercy-panel-header {
    padding: 18px 21px;
    background: #FFFAFC;
    border-bottom: 1px solid #F3E5EC;
}

.mercy-panel-header h4 {
    color: #A63D73;
    font-size: 15px;
    font-weight: 800;
    margin: 0;
}

.mercy-panel-body {
    padding: 17px 21px;
}


/* =============================================
   ACTIVIDAD RECIENTE
============================================= */

.mercy-activity {
    display: flex;
    align-items: center;
    padding: 13px 0;
    border-bottom: 1px solid #F4EAF0;
}

.mercy-activity:last-child {
    border-bottom: none;
}

.mercy-activity-icon {
    width: 43px;
    height: 43px;
    min-width: 43px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 13px;
    background: #FCE8F1;
    color: #C34F87;
    margin-right: 13px;
    font-size: 17px;
}

.mercy-activity strong,
.mercy-product strong {
    color: #79455F;
    font-size: 13px;
}

.mercy-activity small,
.mercy-product small {
    display: block;
    color: #A58A99;
    font-size: 12px;
    margin-top: 5px;
}


/* =============================================
   CONTROL DE STOCK
============================================= */

.mercy-product {
    padding: 14px 0;
    border-bottom: 1px solid #F4EAF0;
}

.mercy-product:last-child {
    border-bottom: none;
}

.mercy-stock {
    float: right;
    background: #FCE8F1;
    color: #B83E7A;
    padding: 5px 10px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 800;
}

.mercy-stock.zero {
    background: #FCE5E5;
    color: #CA5050;
}


/* =============================================
   MENSAJES VACÍOS
============================================= */

.mercy-empty {
    text-align: center;
    color: #A87D96;
    padding: 28px 10px;
}

.mercy-empty i {
    font-size: 30px;
    margin-bottom: 10px;
    color: #D88CB0;
}


/* =============================================
   GRÁFICO DE BARRAS
============================================= */

.mercy-chart {
    position: relative;
    height: 350px;
    width: 100%;
    padding: 20px;
}

.mercy-chart canvas {
    width: 100% !important;
    height: 100% !important;
}


/* =============================================
   RESPONSIVE
============================================= */

@media(max-width:767px) {

    .dashboard-mercy {
        padding: 12px;
    }

    .mercy-banner {
        padding: 23px;
    }

    .mercy-banner h1 {
        font-size: 22px;
    }

    .mercy-banner-info {
        text-align: left;
        margin-top: 20px;
    }

    .mercy-stat {
        min-height: 120px;
    }

    .mercy-chart {
        height: 300px;
        padding: 10px;
    }
}

</style>


<!-- =========================================
     CONTENEDOR PRINCIPAL
========================================= -->

<div class="content-wrapper">

<section class="content">

<div class="dashboard-mercy">


    <!-- =====================================
         BIENVENIDA
    ====================================== -->

    <div class="mercy-banner">

        <div class="row">

            <div class="col-md-8">

                <h1>
                    <i class="fa fa-heart"></i>
                    ¡Bienvenida a VENTAS MERCEDES!
                </h1>

                <p>
                    Administra tu negocio con facilidad.
                    Controla tus artículos, compras, ventas e inventario
                    desde un solo lugar.
                </p>

            </div>

            <div class="col-md-4 mercy-banner-info">

                <strong>
                    <i class="fa fa-calendar"></i>
                    <?php echo date('d/m/Y'); ?>
                </strong>

                <br>

                <span class="mercy-status">
                    <i class="fa fa-check-circle"></i>
                    Sistema activo
                </span>

            </div>

        </div>

    </div>


    <!-- =====================================
         RESUMEN DEL NEGOCIO
    ====================================== -->

    <div class="mercy-section">

        <h3>
            <i class="fa fa-bar-chart"></i>
            Resumen de tu negocio
        </h3>

        <p>Indicadores actualizados de tu sistema.</p>

    </div>


    <div class="row">

        <!-- ARTÍCULOS -->

        <div class="col-md-3 col-sm-6">

            <div class="mercy-stat">

                <div class="mercy-stat-icon icon-rosa">
                    <i class="fa fa-cubes"></i>
                </div>

                <small>Artículos activos</small>

                <h2>
                    <?php echo $articulos; ?>
                </h2>

            </div>

        </div>


        <!-- CATEGORÍAS -->

        <div class="col-md-3 col-sm-6">

            <div class="mercy-stat">

                <div class="mercy-stat-icon icon-lila">
                    <i class="fa fa-tags"></i>
                </div>

                <small>Categorías activas</small>

                <h2>
                    <?php echo $categorias; ?>
                </h2>

            </div>

        </div>


        <!-- STOCK -->

        <div class="col-md-3 col-sm-6">

            <div class="mercy-stat">

                <div class="mercy-stat-icon icon-verde">
                    <i class="fa fa-archive"></i>
                </div>

                <small>Unidades en stock</small>

                <h2>
                    <?php echo number_format($stock); ?>
                </h2>

            </div>

        </div>


        <!-- VENTAS -->

        <div class="col-md-3 col-sm-6">

            <div class="mercy-stat">

                <div class="mercy-stat-icon icon-dorado">
                    <i class="fa fa-money"></i>
                </div>

                <small>Ventas de hoy</small>

                <h2 style="font-size:22px;">
                    S/ <?php echo number_format($ventasHoy, 2); ?>
                </h2>

            </div>

        </div>

    </div>


    <!-- =====================================
         COMPRAS DEL DÍA
    ====================================== -->

    <div class="row">

        <div class="col-md-3 col-sm-6">

            <div class="mercy-stat">

                <div class="mercy-stat-icon icon-lila">
                    <i class="fa fa-shopping-bag"></i>
                </div>

                <small>Compras de hoy</small>

                <h2 style="font-size:22px;">
                    S/ <?php echo number_format($comprasHoy, 2); ?>
                </h2>

            </div>

        </div>

    </div>


    <!-- =====================================
         ACCESOS RÁPIDOS
    ====================================== -->

    <div class="mercy-section">

        <h3>
            <i class="fa fa-bolt"></i>
            Accesos rápidos
        </h3>

        <p>Entra directamente a las funciones principales.</p>

    </div>


    <div class="row">


        <div class="col-md-3 col-sm-6">

            <a href="listado.php" class="mercy-access">

                <div class="mercy-access-icon">
                    <i class="fa fa-cubes"></i>
                </div>

                <h4>Artículos</h4>

                <p>Gestionar productos</p>

            </a>

        </div>


        <div class="col-md-3 col-sm-6">

            <a href="categoria/index.php" class="mercy-access">

                <div class="mercy-access-icon">
                    <i class="fa fa-tags"></i>
                </div>

                <h4>Categorías</h4>

                <p>Administrar categorías</p>

            </a>

        </div>


        <div class="col-md-3 col-sm-6">

            <a href="compras/ingreso.php" class="mercy-access">

                <div class="mercy-access-icon">
                    <i class="fa fa-shopping-bag"></i>
                </div>

                <h4>Compras</h4>

                <p>Registrar compras</p>

            </a>

        </div>


        <div class="col-md-3 col-sm-6">

            <a href="ventas/venta.php" class="mercy-access">

                <div class="mercy-access-icon">
                    <i class="fa fa-shopping-cart"></i>
                </div>

                <h4>Ventas</h4>

                <p>Registrar ventas</p>

            </a>

        </div>

    </div>


    <!-- =====================================
         GRÁFICO DE BARRAS
    ====================================== -->

    <div class="mercy-section">

        <h3>
            <i class="fa fa-bar-chart"></i>
            Rendimiento de tu negocio
        </h3>

        <p>
            Comparación de ventas y compras durante los últimos siete días.
        </p>

    </div>


    <div class="mercy-panel">

        <div class="mercy-panel-header">

            <h4>
                <i class="fa fa-bar-chart"></i>
                Comparativo semanal de ventas y compras
            </h4>

        </div>

        <div class="mercy-chart">

            <canvas id="graficoVentas"></canvas>

        </div>

    </div>


    <!-- =====================================
         ACTIVIDAD E INVENTARIO
    ====================================== -->

    <div class="row">


        <!-- ACTIVIDAD RECIENTE -->

        <div class="col-md-6">

            <div class="mercy-section">

                <h3>
                    <i class="fa fa-history"></i>
                    Actividad reciente
                </h3>

                <p>Últimas operaciones registradas.</p>

            </div>


            <div class="mercy-panel">

                <div class="mercy-panel-header">

                    <h4>Últimas compras y ventas</h4>

                </div>


                <div class="mercy-panel-body">

                    <?php if (empty($actividades)): ?>

                        <div class="mercy-empty">

                            <i class="fa fa-info-circle"></i>

                            <p>
                                Aún no hay movimientos registrados.
                            </p>

                        </div>

                    <?php else: ?>


                        <?php foreach ($actividades as $actividad): ?>

                            <div class="mercy-activity">

                                <div class="mercy-activity-icon">

                                    <i class="fa <?php
                                        echo $actividad['tipo'] === 'Venta'
                                        ? 'fa-shopping-cart'
                                        : 'fa-shopping-bag';
                                    ?>"></i>

                                </div>


                                <div>

                                    <strong>

                                        <?php
                                        echo htmlspecialchars($actividad['tipo']);
                                        ?>

                                        <?php
                                        echo htmlspecialchars(
                                            $actividad['comprobante'] ?? ''
                                        );
                                        ?>

                                    </strong>


                                    <small>

                                        <?php
                                        echo date(
                                            'd/m/Y H:i',
                                            strtotime($actividad['fecha'])
                                        );
                                        ?>

                                        — S/

                                        <?php
                                        echo number_format(
                                            (float)$actividad['total'],
                                            2
                                        );
                                        ?>

                                    </small>

                                </div>

                            </div>

                        <?php endforeach; ?>


                    <?php endif; ?>

                </div>

            </div>

        </div>


        <!-- CONTROL DE INVENTARIO -->

        <div class="col-md-6">

            <div class="mercy-section">

                <h3>
                    <i class="fa fa-exclamation-circle"></i>
                    Control de inventario
                </h3>

                <p>Productos que necesitan reposición.</p>

            </div>


            <div class="mercy-panel">

                <div class="mercy-panel-header">

                    <h4>Alertas de stock bajo</h4>

                </div>


                <div class="mercy-panel-body">


                    <?php if (empty($stockBajo)): ?>

                        <div class="mercy-empty">

                            <i class="fa fa-check-circle"></i>

                            <p>
                                No hay productos con stock bajo.
                            </p>

                        </div>

                    <?php else: ?>


                        <?php foreach ($stockBajo as $producto): ?>

                            <div class="mercy-product">

                                <strong>

                                    <?php
                                    echo htmlspecialchars($producto['nombre']);
                                    ?>

                                </strong>


                                <span class="mercy-stock <?php
                                    echo (int)$producto['stock'] === 0
                                    ? 'zero'
                                    : '';
                                ?>">

                                    <?php
                                    echo (int)$producto['stock'];
                                    ?>

                                    unidades

                                </span>


                                <small>

                                    Código:

                                    <?php
                                    echo htmlspecialchars($producto['codigo']);
                                    ?>

                                </small>

                            </div>

                        <?php endforeach; ?>


                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================
         MENSAJE DE ERROR
    ====================================== -->

    <?php if ($errorDashboard): ?>

        <div class="alert alert-warning">

            <?php
            echo htmlspecialchars($errorDashboard);
            ?>

        </div>

    <?php endif; ?>


    <!-- =====================================
         PIE DEL DASHBOARD
    ====================================== -->

    <div class="text-center"
         style="padding:20px;color:#AD8299;">

        <i class="fa fa-heart"></i>

        VENTAS MERCEDES · Sistema de Gestión

    </div>


</div>

</section>

</div>


<!-- =========================================
     LIBRERÍA CHART.JS
========================================= -->

<script src="../public/plugins/chartjs/Chart.min.js"></script>


<!-- =========================================
     CONFIGURACIÓN DEL GRÁFICO DE BARRAS
========================================= -->

<script>

(function () {

    var elemento = document.getElementById('graficoVentas');

    if (!elemento || typeof Chart === 'undefined') {
        return;
    }

    var etiquetas = <?php
        echo json_encode(array_column($ventasSemana, 'dia'));
    ?>;

    var datosVentas = <?php
        echo json_encode(array_column($ventasSemana, 'total'));
    ?>;

    var datosCompras = <?php
        echo json_encode(array_column($comprasSemana, 'total'));
    ?>;


    new Chart(elemento, {

        type: 'bar',

        data: {

            labels: etiquetas,

            datasets: [

                {
                    label: 'Ventas (S/)',

                    data: datosVentas,

                    backgroundColor: 'rgba(214, 83, 145, 0.82)',

                    borderColor: '#C94F88',

                    borderWidth: 1
                },

                {
                    label: 'Compras (S/)',

                    data: datosCompras,

                    backgroundColor: 'rgba(137, 101, 181, 0.78)',

                    borderColor: '#8965B5',

                    borderWidth: 1
                }

            ]

        },


        options: {

            responsive: true,

            maintainAspectRatio: false,

            legend: {

                display: true,

                position: 'top'

            },

            tooltips: {

                callbacks: {

                    label: function (tooltipItem, data) {

                        var nombre =
                            data.datasets[tooltipItem.datasetIndex].label || '';

                        return nombre + ': S/ ' +
                            Number(tooltipItem.yLabel).toFixed(2);

                    }

                }

            },

            scales: {

                yAxes: [

                    {

                        ticks: {

                            beginAtZero: true,

                            callback: function (valor) {

                                return 'S/ ' + valor;

                            }

                        },

                        scaleLabel: {

                            display: true,

                            labelString: 'Monto en soles (S/)'

                        }

                    }

                ],

                xAxes: [

                    {

                        gridLines: {

                            display: false

                        }

                    }

                ]

            }

        }

    });

})();

</script>


<?php require 'footer.php'; ?>
