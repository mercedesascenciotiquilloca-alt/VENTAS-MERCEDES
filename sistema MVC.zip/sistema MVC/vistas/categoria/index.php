
<?php
require_once __DIR__ . "/../header.php";
?>

<style>
    .categoria-container {
        padding: 25px;
    }

    .categoria-titulo h1 {
        color: #B96880;
        font-size: 27px;
        font-weight: 700;
        margin: 0 0 8px;
    }

    .categoria-titulo p {
        color: #92717D;
        margin-bottom: 22px;
    }

    .categoria-panel {
        background: #fff;
        border-radius: 12px;
        padding: 22px;
        box-shadow: 0 3px 12px rgba(185, 104, 128, .08);
        border: 1px solid #F0DCE2;
    }

    .categoria-panel h3 {
        color: #B96880;
        font-weight: 700;
        margin-top: 0;
    }

    .btn-rosa {
        background: #E98FA8;
        color: #fff;
        border: none;
        border-radius: 7px;
        padding: 9px 16px;
        font-weight: 600;
    }

    .btn-rosa:hover {
        background: #B96880;
        color: #fff;
    }

    .btn-editar {
        background: #E7A6B7;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 6px 10px;
    }

    .btn-estado {
        background: #92717D;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 6px 10px;
    }

    .estado-activo {
        background: #E4F5EA;
        color: #328451;
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 12px;
        font-weight: 700;
    }

    .estado-inactivo {
        background: #FCE8EC;
        color: #B96880;
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 12px;
        font-weight: 700;
    }

    .categoria-modal-fondo {
        display: none;
        position: fixed;
        z-index: 9999;
        inset: 0;
        background: rgba(40, 20, 30, .50);
        justify-content: center;
        align-items: center;
        padding: 15px;
    }

    .categoria-modal {
        background: white;
        width: 100%;
        max-width: 520px;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 8px 30px rgba(0,0,0,.2);
    }

    .categoria-modal-cabecera {
        background: #E98FA8;
        color: white;
        padding: 17px 22px;
        font-size: 18px;
        font-weight: 700;
    }

    .categoria-modal-cuerpo {
        padding: 22px;
    }

    .categoria-modal-pie {
        padding: 15px 22px;
        border-top: 1px solid #eee;
        text-align: right;
    }

    .categoria-modal-cuerpo label {
        color: #684C56;
        font-weight: 600;
    }

    .categoria-modal-cuerpo .form-group {
        margin-bottom: 17px;
    }

    .categoria-mensaje {
        display: none;
        padding: 11px 14px;
        margin-bottom: 15px;
        border-radius: 7px;
    }

    .categoria-mensaje.error {
        display: block;
        background: #FCE8EC;
        color: #A33E59;
    }

    .categoria-mensaje.exito {
        display: block;
        background: #E4F5EA;
        color: #328451;
    }

    .categoria-tabla {
        width: 100%;
    }

    .categoria-tabla tbody td {
        vertical-align: middle !important;
    }

    @media(max-width: 767px) {
        .categoria-container {
            padding: 12px;
        }

        .categoria-panel {
            padding: 14px;
            overflow-x: auto;
        }
    }
</style>

<div class="content-wrapper">

    <section class="content-header">
        <h1>
            <i class="fa fa-tags"></i>
            Gestión de categorías
            <small>Administración de categorías de ropa</small>
        </h1>
    </section>

    <section class="content categoria-container">

        <div class="categoria-titulo">
            <h1>Mis categorías</h1>
            <p>Registra, consulta, modifica y administra las categorías de tus artículos.</p>
        </div>

        <div class="categoria-panel">

            <div class="row" style="margin-bottom:20px;">

                <div class="col-sm-8">
                    <h3>
                        <i class="fa fa-list"></i>
                        Listado de categorías
                    </h3>
                </div>

                <div class="col-sm-4 text-right">
                    <button type="button"
                            class="btn btn-rosa"
                            onclick="abrirNuevo()">
                        <i class="fa fa-plus"></i>
                        Nueva categoría
                    </button>
                </div>

            </div>

            <div id="mensajeGeneral" class="categoria-mensaje"></div>

            <div class="table-responsive">

                <table class="table table-bordered table-hover categoria-tabla">

                    <thead>
                        <tr>
                            <th style="width:70px;">ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th style="width:110px;">Estado</th>
                            <th style="width:160px;">Acciones</th>
                        </tr>
                    </thead>

                    <tbody id="tablaCategorias">
                        <tr>
                            <td colspan="5" class="text-center">
                                Cargando categorías...
                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>

            <div id="totalCategorias"
                 style="color:#92717D; font-weight:600; margin-top:12px;">
            </div>

        </div>

    </section>

</div>

<!-- MODAL DE CATEGORÍA -->
<div class="categoria-modal-fondo" id="modalCategoria">

    <div class="categoria-modal">

        <div class="categoria-modal-cabecera" id="tituloModal">
            Nueva categoría
        </div>

        <form id="formCategoria">

            <div class="categoria-modal-cuerpo">

                <div id="mensajeModal" class="categoria-mensaje"></div>

                <input type="hidden" id="categoriaId" name="id">

                <div class="form-group">
                    <label for="nombreCategoria">Nombre de la categoría *</label>

                    <input type="text"
                           class="form-control"
                           id="nombreCategoria"
                           name="nombre"
                           maxlength="100"
                           placeholder="Ejemplo: Polos"
                           required>
                </div>

                <div class="form-group">
                    <label for="descripcionCategoria">Descripción</label>

                    <textarea class="form-control"
                              id="descripcionCategoria"
                              name="descripcion"
                              rows="3"
                              maxlength="255"
                              placeholder="Descripción de la categoría"></textarea>
                </div>

            </div>

            <div class="categoria-modal-pie">

                <button type="button"
                        class="btn btn-default"
                        onclick="cerrarModal()">
                    Cancelar
                </button>

                <button type="submit"
                        class="btn btn-rosa"
                        id="btnGuardar">
                    <i class="fa fa-save"></i>
                    Guardar
                </button>

            </div>

        </form>

    </div>

</div>

<script>
const URL_CATEGORIA = "../ajax/categoria.php";

const tablaCategorias = document.getElementById("tablaCategorias");
const modalCategoria = document.getElementById("modalCategoria");
const formCategoria = document.getElementById("formCategoria");

let categorias = [];

function mostrarMensaje(texto, tipo) {
    const mensaje = document.getElementById("mensajeGeneral");

    mensaje.textContent = texto;
    mensaje.className = "categoria-mensaje " + tipo;

    setTimeout(() => {
        mensaje.className = "categoria-mensaje";
        mensaje.textContent = "";
    }, 4000);
}

function crearCelda(fila, contenido) {
    const celda = document.createElement("td");
    celda.textContent = contenido;
    fila.appendChild(celda);
    return celda;
}

async function cargarCategorias() {
    tablaCategorias.innerHTML = `
        <tr>
            <td colspan="5" class="text-center">Cargando categorías...</td>
        </tr>
    `;

    try {
        const respuesta = await fetch(URL_CATEGORIA + "?accion=listar");
        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudieron cargar las categorías.");
        }

        categorias = resultado.data;
        dibujarCategorias();

    } catch (error) {
        tablaCategorias.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-danger"></td>
            </tr>
        `;

        tablaCategorias.querySelector("td").textContent = error.message;
    }
}

function dibujarCategorias() {
    tablaCategorias.innerHTML = "";

    if (!categorias.length) {
        const fila = document.createElement("tr");
        const celda = crearCelda(fila, "No hay categorías registradas.");
        celda.colSpan = 5;
        celda.className = "text-center";
        tablaCategorias.appendChild(fila);
    }

    categorias.forEach(categoria => {

        const fila = document.createElement("tr");

        crearCelda(fila, categoria.id);
        crearCelda(fila, categoria.nombre);
        crearCelda(fila, categoria.descripcion || "Sin descripción");

        const celdaEstado = document.createElement("td");
        const etiqueta = document.createElement("span");

        etiqueta.textContent = categoria.estado;

        etiqueta.className = categoria.estado === "Activo"
            ? "estado-activo"
            : "estado-inactivo";

        celdaEstado.appendChild(etiqueta);
        fila.appendChild(celdaEstado);

        const celdaAcciones = document.createElement("td");

        const botonEditar = document.createElement("button");
        botonEditar.type = "button";
        botonEditar.className = "btn-editar";
        botonEditar.innerHTML = '<i class="fa fa-pencil"></i> Editar';
        botonEditar.style.marginRight = "5px";
        botonEditar.addEventListener("click", () => editarCategoria(categoria.id));

        const botonEstado = document.createElement("button");
        botonEstado.type = "button";
        botonEstado.className = "btn-estado";

        const nuevoEstado = categoria.estado === "Activo" ? "Inactivo" : "Activo";

        botonEstado.innerHTML = categoria.estado === "Activo"
            ? '<i class="fa fa-ban"></i>'
            : '<i class="fa fa-check"></i>';

        botonEstado.title = "Cambiar a " + nuevoEstado;
        botonEstado.addEventListener("click", () => cambiarEstado(categoria.id, nuevoEstado));

        celdaAcciones.appendChild(botonEditar);
        celdaAcciones.appendChild(botonEstado);

        fila.appendChild(celdaAcciones);

        tablaCategorias.appendChild(fila);
    });

    document.getElementById("totalCategorias").textContent =
        "Total de categorías: " + categorias.length;
}

function abrirNuevo() {
    formCategoria.reset();

    document.getElementById("categoriaId").value = "";
    document.getElementById("tituloModal").textContent = "Nueva categoría";
    document.getElementById("mensajeModal").className = "categoria-mensaje";

    modalCategoria.style.display = "flex";
    document.getElementById("nombreCategoria").focus();
}

function editarCategoria(id) {
    const categoria = categorias.find(item => String(item.id) === String(id));

    if (!categoria) {
        mostrarMensaje("No se encontró la categoría.", "error");
        return;
    }

    formCategoria.reset();

    document.getElementById("categoriaId").value = categoria.id;
    document.getElementById("nombreCategoria").value = categoria.nombre;
    document.getElementById("descripcionCategoria").value = categoria.descripcion || "";
    document.getElementById("tituloModal").textContent = "Editar categoría";
    document.getElementById("mensajeModal").className = "categoria-mensaje";

    modalCategoria.style.display = "flex";
}

function cerrarModal() {
    modalCategoria.style.display = "none";
}

formCategoria.addEventListener("submit", async function(evento) {
    evento.preventDefault();

    const id = document.getElementById("categoriaId").value;
    const accion = id ? "editar" : "agregar";

    const datos = new FormData(formCategoria);
    datos.append("accion", accion);

    const boton = document.getElementById("btnGuardar");
    boton.disabled = true;
    boton.textContent = "Guardando...";

    try {
        const respuesta = await fetch(URL_CATEGORIA, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo guardar la categoría.");
        }

        cerrarModal();
        formCategoria.reset();

        mostrarMensaje(resultado.mensaje, "exito");

        await cargarCategorias();

    } catch (error) {
        const mensaje = document.getElementById("mensajeModal");
        mensaje.textContent = error.message;
        mensaje.className = "categoria-mensaje error";

    } finally {
        boton.disabled = false;
        boton.innerHTML = '<i class="fa fa-save"></i> Guardar';
    }
});

async function cambiarEstado(id, estado) {
    const confirmacion = confirm(
        "¿Deseas cambiar el estado de esta categoría a " + estado + "?"
    );

    if (!confirmacion) {
        return;
    }

    const datos = new FormData();
    datos.append("accion", "cambiarEstado");
    datos.append("id", id);
    datos.append("estado", estado);

    try {
        const respuesta = await fetch(URL_CATEGORIA, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo cambiar el estado.");
        }

        mostrarMensaje(resultado.mensaje, "exito");

        await cargarCategorias();

    } catch (error) {
        mostrarMensaje(error.message, "error");
    }
}

modalCategoria.addEventListener("click", function(evento) {
    if (evento.target === modalCategoria) {
        cerrarModal();
    }
});

cargarCategorias();
</script>

<?php
require_once __DIR__ . "/../footer.php";
?>
