
<?php
require_once '../header.php';
?>

<style>
.venta-container {
    padding: 25px;
}

.venta-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
    margin: 0 0 8px;
}

.venta-titulo p {
    color: #92717D;
}

.venta-card {
    background: #fff;
    border-radius: 12px;
    padding: 22px;
    margin-bottom: 20px;
    box-shadow: 0 3px 15px rgba(185,104,128,.10);
}

.venta-card h3 {
    color: #B96880;
    font-size: 18px;
    font-weight: 700;
    margin-top: 0;
    margin-bottom: 20px;
}

.venta-card .form-control:focus {
    border-color: #B96880;
    box-shadow: 0 0 5px rgba(185,104,128,.25);
}

.btn-venta {
    background: #B96880;
    color: white;
    border: none;
}

.btn-venta:hover,
.btn-venta:focus {
    background: #a6536d;
    color: white;
}

.tabla-venta thead {
    background: #f8e8ed;
    color: #945267;
}

.tabla-venta th,
.tabla-venta td {
    vertical-align: middle !important;
}

.venta-total {
    background: #fff0f4;
    border-radius: 10px;
    padding: 18px;
    text-align: right;
    color: #945267;
}

.venta-total strong {
    font-size: 25px;
    color: #B96880;
}

.estado-registrada {
    background: #e4f5e9;
    color: #26834a;
    padding: 5px 10px;
    border-radius: 20px;
}

.estado-anulada {
    background: #fce5e8;
    color: #bd5264;
    padding: 5px 10px;
    border-radius: 20px;
}
</style>

<div class="content-wrapper">

<section class="content-header">
    <div class="venta-container">
        <div class="venta-titulo">
            <h1><i class="fa fa-shopping-cart"></i> Registro de Ventas</h1>
            <p>Registra las ventas y controla el stock de tus prendas.</p>
        </div>
    </div>
</section>

<section class="content">
<div class="venta-container">

    <!-- DATOS DE LA VENTA -->
    <div class="venta-card">
        <h3><i class="fa fa-file-text-o"></i> Datos de la venta</h3>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Cliente</label>
                    <select id="cliente_id" class="form-control">
                        <option value="">Venta sin cliente</option>
                    </select>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Comprobante</label>
                    <input type="text" id="comprobante"
                           class="form-control"
                           placeholder="Ejemplo: B001-000001"
                           maxlength="50">
                </div>
            </div>
        </div>
    </div>

    <!-- AGREGAR PRODUCTOS -->
    <div class="venta-card">
        <h3><i class="fa fa-tags"></i> Productos de la venta</h3>

        <div class="row">
            <div class="col-md-5">
                <div class="form-group">
                    <label>Prenda - Talla - Color</label>
                    <select id="variante_id" class="form-control">
                        <option value="">Seleccionar producto</option>
                    </select>
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label>Stock disponible</label>
                    <input type="text" id="stockDisponible"
                           class="form-control" readonly value="0">
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label>Precio unitario</label>
                    <input type="text" id="precioUnitario"
                           class="form-control" readonly value="S/ 0.00">
                </div>
            </div>

            <div class="col-md-1">
                <div class="form-group">
                    <label>Cantidad</label>
                    <input type="number" id="cantidad"
                           class="form-control" min="1" value="1">
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label>&nbsp;</label>
                    <button type="button" class="btn btn-venta btn-block"
                            onclick="agregarProducto()">
                        <i class="fa fa-plus"></i> Agregar
                    </button>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover tabla-venta">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Talla</th>
                        <th>Color</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Subtotal</th>
                        <th width="70">Acción</th>
                    </tr>
                </thead>
                <tbody id="tablaDetalle">
                    <tr>
                        <td colspan="7" class="text-center">
                            Agrega productos a la venta.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-md-7"></div>
            <div class="col-md-5">
                <div class="venta-total">
                    <span>Total de la venta</span><br>
                    <strong id="totalVenta">S/ 0.00</strong>
                </div>
            </div>
        </div>

        <div class="text-right" style="margin-top:20px;">
            <button type="button" class="btn btn-default"
                    onclick="limpiarVenta()">
                <i class="fa fa-refresh"></i> Limpiar
            </button>

            <button type="button" class="btn btn-venta"
                    onclick="registrarVenta()">
                <i class="fa fa-save"></i> Registrar venta
            </button>
        </div>
    </div>

    <!-- HISTORIAL -->
    <div class="venta-card">
        <h3><i class="fa fa-history"></i> Historial de ventas</h3>

        <div class="row" style="margin-bottom:15px;">
            <div class="col-md-6">
                <input type="text" id="buscarVenta"
                       class="form-control"
                       placeholder="Buscar por cliente o comprobante...">
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover tabla-venta">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Comprobante</th>
                        <th>Productos</th>
                        <th>Total</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody id="tablaHistorial">
                    <tr>
                        <td colspan="7" class="text-center">
                            Cargando historial...
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
</section>
</div>

<script>
const URL_VENTA = "../ajax/venta.php";

let clientesVenta = [];
let variantesVenta = [];
let carritoVenta = [];
let historialVentas = [];

function escaparVenta(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, function(letra) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[letra];
    });
}

function dinero(valor) {
    return "S/ " + Number(valor || 0).toFixed(2);
}

// Cargar clientes y productos disponibles
async function cargarDatosVenta() {
    try {
        const respuesta = await fetch(URL_VENTA + "?op=datos");
        const datos = await respuesta.json();

        clientesVenta = datos.clientes || [];
        variantesVenta = datos.variantes || [];

        const selectCliente = document.getElementById("cliente_id");

        selectCliente.innerHTML =
            '<option value="">Venta sin cliente</option>';

        clientesVenta.forEach(c => {
            selectCliente.innerHTML += `
                <option value="${Number(c.id)}">
                    ${escaparVenta(c.nombre)}
                    ${c.documento ? " - " + escaparVenta(c.documento) : ""}
                </option>
            `;
        });

        actualizarSelectVariantes();
        await cargarHistorialVentas();

    } catch (error) {
        alert("No se pudieron cargar los datos de ventas. Revisa ajax/venta.php.");
    }
}

// Mostrar productos disponibles
function actualizarSelectVariantes() {
    const select = document.getElementById("variante_id");

    select.innerHTML = '<option value="">Seleccionar producto</option>';

    variantesVenta
        .filter(v => Number(v.stock) > 0)
        .forEach(v => {
            select.innerHTML += `
                <option value="${Number(v.id)}">
                    ${escaparVenta(v.articulo)}
                    | Talla: ${escaparVenta(v.talla)}
                    | Color: ${escaparVenta(v.color)}
                    | Stock: ${Number(v.stock)}
                </option>
            `;
        });

    document.getElementById("stockDisponible").value = "0";
    document.getElementById("precioUnitario").value = "S/ 0.00";
}

// Mostrar stock y precio del producto seleccionado
document.getElementById("variante_id").addEventListener("change", function() {
    const id = Number(this.value);
    const producto = variantesVenta.find(v => Number(v.id) === id);

    if (!producto) {
        document.getElementById("stockDisponible").value = "0";
        document.getElementById("precioUnitario").value = "S/ 0.00";
        return;
    }

    document.getElementById("stockDisponible").value = producto.stock;
    document.getElementById("precioUnitario").value = dinero(producto.precio);
});

// Agregar producto al carrito
function agregarProducto() {
    const id = Number(document.getElementById("variante_id").value);
    const cantidad = Number(document.getElementById("cantidad").value);

    const producto = variantesVenta.find(v => Number(v.id) === id);

    if (!producto) {
        alert("Selecciona una prenda.");
        return;
    }

    if (!Number.isInteger(cantidad) || cantidad <= 0) {
        alert("Ingresa una cantidad válida.");
        return;
    }

    const existente = carritoVenta.find(p => Number(p.variante_id) === id);
    const cantidadActual = existente ? existente.cantidad : 0;

    if (cantidadActual + cantidad > Number(producto.stock)) {
        alert("Stock insuficiente. Disponible: " + producto.stock);
        return;
    }

    if (existente) {
        existente.cantidad += cantidad;
    } else {
        carritoVenta.push({
            variante_id: Number(producto.id),
            articulo: producto.articulo,
            talla: producto.talla,
            color: producto.color,
            precio: Number(producto.precio),
            cantidad: cantidad
        });
    }

    document.getElementById("cantidad").value = 1;
    document.getElementById("variante_id").value = "";

    actualizarSelectVariantes();
    mostrarDetalleVenta();
}

// Dibujar carrito y total
function mostrarDetalleVenta() {
    const tabla = document.getElementById("tablaDetalle");

    if (carritoVenta.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="7" class="text-center">
                    Agrega productos a la venta.
                </td>
            </tr>
        `;
        document.getElementById("totalVenta").textContent = dinero(0);
        return;
    }

    let total = 0;

    tabla.innerHTML = carritoVenta.map((p, i) => {
        const subtotal = p.precio * p.cantidad;
        total += subtotal;

        return `
            <tr>
                <td>${escaparVenta(p.articulo)}</td>
                <td>${escaparVenta(p.talla)}</td>
                <td>${escaparVenta(p.color)}</td>
                <td>${dinero(p.precio)}</td>
                <td>${p.cantidad}</td>
                <td>${dinero(subtotal)}</td>
                <td>
                    <button type="button"
                        class="btn btn-danger btn-xs"
                        onclick="quitarProducto(${i})">
                        <i class="fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join("");

    document.getElementById("totalVenta").textContent = dinero(total);
}

// Quitar producto
function quitarProducto(indice) {
    carritoVenta.splice(indice, 1);
    mostrarDetalleVenta();
}

// Limpiar venta
function limpiarVenta() {
    if (carritoVenta.length > 0 &&
        !confirm("¿Deseas limpiar los productos de esta venta?")) {
        return;
    }

    carritoVenta = [];
    document.getElementById("cliente_id").value = "";
    document.getElementById("comprobante").value = "";
    document.getElementById("cantidad").value = 1;

    actualizarSelectVariantes();
    mostrarDetalleVenta();
}

// Registrar venta
async function registrarVenta() {
    if (carritoVenta.length === 0) {
        alert("Agrega al menos un producto.");
        return;
    }

    if (!confirm("¿Deseas registrar esta venta? Se descontará el stock.")) {
        return;
    }

    const datos = new FormData();

    datos.append("cliente_id", document.getElementById("cliente_id").value);
    datos.append("comprobante", document.getElementById("comprobante").value);

    datos.append("detalles", JSON.stringify(
        carritoVenta.map(p => ({
            variante_id: p.variante_id,
            cantidad: p.cantidad
        }))
    ));

    try {
        const respuesta = await fetch(URL_VENTA + "?op=registrar", {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!resultado.ok) {
            alert(resultado.error || "No se pudo registrar la venta.");
            await cargarDatosVenta();
            return;
        }

        alert(
            resultado.mensaje +
            "\nNúmero de venta: " + resultado.venta_id +
            "\nTotal: " + dinero(resultado.total)
        );

        carritoVenta = [];
        document.getElementById("cliente_id").value = "";
        document.getElementById("comprobante").value = "";
        document.getElementById("cantidad").value = 1;

        mostrarDetalleVenta();
        await cargarDatosVenta();

    } catch (error) {
        alert("Ocurrió un error al registrar la venta. Verifica la conexión.");
    }
}

// Cargar historial
async function cargarHistorialVentas() {
    try {
        const respuesta = await fetch(URL_VENTA + "?op=listar");
        historialVentas = await respuesta.json();

        mostrarHistorialVentas(historialVentas);

    } catch (error) {
        document.getElementById("tablaHistorial").innerHTML =
            '<tr><td colspan="7" class="text-center text-danger">Error al cargar el historial.</td></tr>';
    }
}

// Mostrar historial
function mostrarHistorialVentas(datos) {
    const tabla = document.getElementById("tablaHistorial");

    if (!Array.isArray(datos) || datos.length === 0) {
        tabla.innerHTML =
            '<tr><td colspan="7" class="text-center">Todavía no hay ventas registradas.</td></tr>';
        return;
    }

    tabla.innerHTML = datos.map(v => {
        const estado = v.estado === "Registrada";

        return `
            <tr>
                <td>${Number(v.id)}</td>
                <td>${escaparVenta(v.cliente)}</td>
                <td>${escaparVenta(v.fecha_venta)}</td>
                <td>${escaparVenta(v.comprobante || "-")}</td>
                <td>${Number(v.productos)}</td>
                <td><strong>${dinero(v.total)}</strong></td>
                <td>
                    <span class="${estado ? 'estado-registrada' : 'estado-anulada'}">
                        ${escaparVenta(v.estado)}
                    </span>
                </td>
            </tr>
        `;
    }).join("");
}

// Buscar en historial
document.getElementById("buscarVenta").addEventListener("input", function() {
    const texto = this.value.toLowerCase();

    const filtrados = historialVentas.filter(v =>
        String(v.cliente ?? "").toLowerCase().includes(texto) ||
        String(v.comprobante ?? "").toLowerCase().includes(texto) ||
        String(v.id ?? "").includes(texto)
    );

    mostrarHistorialVentas(filtrados);
});

// Iniciar módulo
cargarDatosVenta();
mostrarDetalleVenta();
</script>

<?php
require_once '../footer.php';
?>
