
<?php
require_once '../header.php';
?>

<style>
.clientes-container {
    padding: 25px;
}

.clientes-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
    margin-bottom: 5px;
}

.clientes-titulo p {
    color: #92717D;
}

.clientes-card {
    background: #fff;
    border-radius: 12px;
    padding: 22px;
    box-shadow: 0 3px 15px rgba(185,104,128,.10);
    margin-top: 20px;
}

.btn-rosa {
    background: #B96880;
    color: white;
    border: none;
}

.btn-rosa:hover {
    background: #a6536d;
    color: white;
}

.form-control:focus {
    border-color: #B96880;
    box-shadow: 0 0 5px rgba(185,104,128,.25);
}

.tabla-clientes thead {
    background: #f8e8ed;
    color: #945267;
}

.tabla-clientes th,
.tabla-clientes td {
    vertical-align: middle !important;
}

.estado-activo {
    background: #e4f5e9;
    color: #26834a;
    padding: 5px 10px;
    border-radius: 20px;
}

.estado-inactivo {
    background: #fce5e8;
    color: #bd5264;
    padding: 5px 10px;
    border-radius: 20px;
}
</style>

<div class="content-wrapper">
<section class="content-header">
    <div class="clientes-container">
        <div class="clientes-titulo">
            <h1><i class="fa fa-users"></i> Gestión de Clientes</h1>
            <p>Administra los clientes de tu negocio.</p>
        </div>
    </div>
</section>

<section class="content">
<div class="clientes-container">

    <div class="clientes-card">
        <div class="row">
            <div class="col-md-8">
                <input type="text" id="buscarCliente"
                       class="form-control"
                       placeholder="Buscar cliente por nombre o documento...">
            </div>
            <div class="col-md-4 text-right">
                <button class="btn btn-rosa" onclick="nuevoCliente()">
                    <i class="fa fa-plus"></i> Nuevo cliente
                </button>
            </div>
        </div>
    </div>

    <div class="clientes-card">
        <div class="table-responsive">
            <table class="table table-bordered table-hover tabla-clientes">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Documento</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Dirección</th>
                        <th>Estado</th>
                        <th width="120">Acciones</th>
                    </tr>
                </thead>
                <tbody id="tablaClientes">
                    <tr>
                        <td colspan="8" class="text-center">Cargando clientes...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
</section>
</div>

<!-- MODAL CLIENTE -->
<div class="modal fade" id="modalCliente" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header" style="background:#B96880;color:white;">
                <button type="button" class="close" data-dismiss="modal"
                        style="color:white;opacity:1;">&times;</button>
                <h4 class="modal-title" id="tituloModal">Nuevo cliente</h4>
            </div>

            <div class="modal-body">
                <form id="formCliente">
                    <input type="hidden" id="id" name="id">

                    <div class="form-group">
                        <label>Nombre completo *</label>
                        <input type="text" class="form-control"
                               id="nombre" name="nombre" required maxlength="150">
                    </div>

                    <div class="form-group">
                        <label>Documento</label>
                        <input type="text" class="form-control"
                               id="documento" name="documento" maxlength="20">
                    </div>

                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="text" class="form-control"
                               id="telefono" name="telefono" maxlength="20">
                    </div>

                    <div class="form-group">
                        <label>Correo electrónico</label>
                        <input type="email" class="form-control"
                               id="correo" name="correo" maxlength="100">
                    </div>

                    <div class="form-group">
                        <label>Dirección</label>
                        <input type="text" class="form-control"
                               id="direccion" name="direccion" maxlength="255">
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-rosa"
                        onclick="guardarCliente()">
                    <i class="fa fa-save"></i> Guardar
                </button>
            </div>

        </div>
    </div>
</div>

<script>
const URL_CLIENTE = "../ajax/cliente.php";

let clientes = [];

function escapar(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, function(letra) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[letra];
    });
}

async function cargarClientes() {
    try {
        const respuesta = await fetch(URL_CLIENTE + "?op=listar");
        clientes = await respuesta.json();
        mostrarClientes(clientes);
    } catch (error) {
        document.getElementById("tablaClientes").innerHTML =
            '<tr><td colspan="8" class="text-center text-danger">Error al cargar clientes. Revisa ajax/cliente.php.</td></tr>';
    }
}

function mostrarClientes(datos) {
    const tabla = document.getElementById("tablaClientes");

    if (!Array.isArray(datos) || datos.length === 0) {
        tabla.innerHTML =
            '<tr><td colspan="8" class="text-center">No hay clientes registrados.</td></tr>';
        return;
    }

    tabla.innerHTML = datos.map((c, i) => {
        const activo = c.estado === "Activo";

        return `
        <tr>
            <td>${i + 1}</td>
            <td>${escapar(c.nombre)}</td>
            <td>${escapar(c.documento)}</td>
            <td>${escapar(c.telefono)}</td>
            <td>${escapar(c.correo)}</td>
            <td>${escapar(c.direccion)}</td>
            <td>
                <span class="${activo ? 'estado-activo' : 'estado-inactivo'}">
                    ${escapar(c.estado)}
                </span>
            </td>
            <td>
                <button class="btn btn-warning btn-xs"
                    onclick="editarCliente(${Number(c.id)})"
                    title="Editar">
                    <i class="fa fa-pencil"></i>
                </button>

                <button class="btn ${activo ? 'btn-danger' : 'btn-success'} btn-xs"
                    onclick="cambiarEstado(${Number(c.id)}, '${activo ? 'Inactivo' : 'Activo'}')"
                    title="${activo ? 'Desactivar' : 'Activar'}">
                    <i class="fa ${activo ? 'fa-ban' : 'fa-check'}"></i>
                </button>
            </td>
        </tr>`;
    }).join("");
}

function nuevoCliente() {
    document.getElementById("formCliente").reset();
    document.getElementById("id").value = "";
    document.getElementById("tituloModal").textContent = "Nuevo cliente";
    $("#modalCliente").modal("show");
}

function editarCliente(id) {
    const c = clientes.find(item => Number(item.id) === Number(id));

    if (!c) return;

    document.getElementById("id").value = c.id;
    document.getElementById("nombre").value = c.nombre ?? "";
    document.getElementById("documento").value = c.documento ?? "";
    document.getElementById("telefono").value = c.telefono ?? "";
    document.getElementById("correo").value = c.correo ?? "";
    document.getElementById("direccion").value = c.direccion ?? "";

    document.getElementById("tituloModal").textContent = "Editar cliente";
    $("#modalCliente").modal("show");
}

async function guardarCliente() {
    const formulario = document.getElementById("formCliente");

    if (!formulario.reportValidity()) return;

    const datos = new FormData(formulario);
    const id = datos.get("id");

    try {
        const respuesta = await fetch(
            URL_CLIENTE + "?op=" + (id ? "editar" : "agregar"),
            {
                method: "POST",
                body: datos
            }
        );

        const resultado = await respuesta.json();

        if (resultado === false || resultado.error) {
            alert(resultado.error || "No se pudo guardar el cliente.");
            return;
        }

        $("#modalCliente").modal("hide");
        alert("Cliente guardado correctamente.");
        cargarClientes();

    } catch (error) {
        alert("Error al guardar. Revisa el modelo y ajax de clientes.");
    }
}

async function cambiarEstado(id, estado) {
    if (!confirm("¿Deseas cambiar el estado de este cliente?")) return;

    const datos = new FormData();
    datos.append("id", id);
    datos.append("estado", estado);

    try {
        const respuesta = await fetch(URL_CLIENTE + "?op=cambiarEstado", {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (resultado === false || resultado.error) {
            alert(resultado.error || "No se pudo cambiar el estado.");
            return;
        }

        cargarClientes();

    } catch (error) {
        alert("Error al cambiar el estado del cliente.");
    }
}

document.getElementById("buscarCliente").addEventListener("input", function() {
    const texto = this.value.toLowerCase();

    const filtrados = clientes.filter(c =>
        String(c.nombre ?? "").toLowerCase().includes(texto) ||
        String(c.documento ?? "").toLowerCase().includes(texto)
    );

    mostrarClientes(filtrados);
});

cargarClientes();
</script>

<?php
require_once '../footer.php';
?>
