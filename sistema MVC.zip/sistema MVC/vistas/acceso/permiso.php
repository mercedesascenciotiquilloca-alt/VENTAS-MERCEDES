
<?php
require_once '../header.php';
?>

<style>
.permiso-container {
    padding: 25px;
}

.permiso-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
}

.permiso-titulo p {
    color: #92717D;
}

.permiso-card {
    background: #fff;
    border-radius: 12px;
    padding: 22px;
    margin-top: 20px;
    box-shadow: 0 3px 15px rgba(185,104,128,.10);
}

.permiso-card h3 {
    color: #B96880;
    font-size: 18px;
    font-weight: 700;
    margin-top: 0;
}

.tabla-permisos thead {
    background: #f8e8ed;
    color: #945267;
}

.tabla-permisos th,
.tabla-permisos td {
    vertical-align: middle !important;
    text-align: center;
}

.tabla-permisos td:first-child,
.tabla-permisos th:first-child {
    text-align: left;
}

.tabla-permisos input {
    width: 17px;
    height: 17px;
    accent-color: #B96880;
    cursor: pointer;
}

.btn-rosa {
    background: #B96880;
    color: white;
    border: none;
}

.btn-rosa:hover {
    background: #a6536d;
    color: white;
}

.permiso-ayuda {
    color: #92717D;
    margin-top: 12px;
}
</style>

<div class="content-wrapper">

<section class="content-header">
    <div class="permiso-container">
        <div class="permiso-titulo">
            <h1><i class="fa fa-lock"></i> Gestión de Permisos</h1>
            <p>Asigna los accesos y las operaciones permitidas a cada usuario.</p>
        </div>
    </div>
</section>

<section class="content">
<div class="permiso-container">

    <div class="permiso-card">
        <h3><i class="fa fa-user"></i> Seleccionar usuario</h3>

        <div class="form-group">
            <label>Usuario</label>
            <select id="idusuario" class="form-control">
                <option value="">Seleccionar usuario</option>
            </select>
        </div>

        <p class="permiso-ayuda">
            Selecciona un usuario para consultar y modificar sus permisos.
        </p>
    </div>

    <div class="permiso-card">
        <h3><i class="fa fa-key"></i> Permisos por módulo</h3>

        <div class="table-responsive">
            <table class="table table-bordered table-hover tabla-permisos">
                <thead>
                    <tr>
                        <th>Módulo</th>
                        <th>Leer</th>
                        <th>Escribir</th>
                        <th>Actualizar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>

                <tbody id="tablaPermisos">
                    <tr>
                        <td colspan="5">
                            Selecciona un usuario para cargar sus permisos.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <button type="button" class="btn btn-default"
                        onclick="marcarTodos(true)">
                    <i class="fa fa-check-square"></i> Marcar todos
                </button>

                <button type="button" class="btn btn-default"
                        onclick="marcarTodos(false)">
                    <i class="fa fa-square-o"></i> Desmarcar todos
                </button>
            </div>

            <div class="col-sm-6 text-right">
                <button type="button" class="btn btn-rosa"
                        onclick="guardarPermisos()">
                    <i class="fa fa-save"></i> Guardar permisos
                </button>
            </div>
        </div>
    </div>

</div>
</section>
</div>

<script>
const URL_PERMISO = "../ajax/permiso.php";

let modulosPermiso = [];

async function cargarDatosPermiso() {
    try {
        const respuesta = await fetch(URL_PERMISO + "?op=datos");
        const datos = await respuesta.json();

        if (datos.error) {
            alert(datos.error);
            return;
        }

        modulosPermiso = datos.modulos || [];

        const select = document.getElementById("idusuario");
        select.innerHTML = '<option value="">Seleccionar usuario</option>';

        (datos.usuarios || []).forEach(u => {
            select.innerHTML += `
                <option value="${Number(u.idusuario)}">
                    ${escapar(u.nombre)} (${escapar(u.usuario)})
                </option>
            `;
        });

    } catch (error) {
        alert("No se pudieron cargar los usuarios y módulos.");
    }
}

function escapar(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, function(letra) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[letra];
    });
}

document.getElementById("idusuario").addEventListener("change", function() {
    cargarPermisos(this.value);
});

async function cargarPermisos(idusuario) {
    const tabla = document.getElementById("tablaPermisos");

    if (!idusuario) {
        tabla.innerHTML = `
            <tr>
                <td colspan="5">Selecciona un usuario para cargar sus permisos.</td>
            </tr>
        `;
        return;
    }

    tabla.innerHTML = `
        <tr>
            <td colspan="5">Cargando permisos...</td>
        </tr>
    `;

    try {
        const respuesta = await fetch(
            URL_PERMISO + "?op=listar&idusuario=" + encodeURIComponent(idusuario)
        );

        const permisos = await respuesta.json();

        if (!Array.isArray(permisos)) {
            throw new Error("Respuesta inválida.");
        }

        if (permisos.length === 0) {
            tabla.innerHTML = `
                <tr>
                    <td colspan="5">No hay módulos registrados.</td>
                </tr>
            `;
            return;
        }

        tabla.innerHTML = permisos.map(p => `
            <tr data-modulo="${Number(p.idmodulo)}">
                <td>${escapar(p.modulo)}</td>

                <td>
                    <input type="checkbox" class="permiso-leer"
                        ${Number(p.leer) === 1 ? "checked" : ""}>
                </td>

                <td>
                    <input type="checkbox" class="permiso-escribir"
                        ${Number(p.escribir) === 1 ? "checked" : ""}>
                </td>

                <td>
                    <input type="checkbox" class="permiso-actualizar"
                        ${Number(p.actualizar) === 1 ? "checked" : ""}>
                </td>

                <td>
                    <input type="checkbox" class="permiso-eliminar"
                        ${Number(p.eliminar) === 1 ? "checked" : ""}>
                </td>
            </tr>
        `).join("");

    } catch (error) {
        tabla.innerHTML = `
            <tr>
                <td colspan="5" class="text-danger">
                    Error al cargar los permisos.
                </td>
            </tr>
        `;
    }
}

function marcarTodos(estado) {
    document.querySelectorAll(
        "#tablaPermisos input[type='checkbox']"
    ).forEach(c => {
        c.checked = estado;
    });
}

async function guardarPermisos() {
    const idusuario = document.getElementById("idusuario").value;

    if (!idusuario) {
        alert("Primero selecciona un usuario.");
        return;
    }

    const filas = document.querySelectorAll(
        "#tablaPermisos tr[data-modulo]"
    );

    if (filas.length === 0) {
        alert("No hay permisos para guardar.");
        return;
    }

    const permisos = Array.from(filas).map(fila => ({
        idmodulo: Number(fila.dataset.modulo),
        leer: fila.querySelector(".permiso-leer").checked ? 1 : 0,
        escribir: fila.querySelector(".permiso-escribir").checked ? 1 : 0,
        actualizar: fila.querySelector(".permiso-actualizar").checked ? 1 : 0,
        eliminar: fila.querySelector(".permiso-eliminar").checked ? 1 : 0
    }));

    const datos = new FormData();
    datos.append("idusuario", idusuario);
    datos.append("permisos", JSON.stringify(permisos));

    try {
        const respuesta = await fetch(URL_PERMISO + "?op=guardar", {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!resultado.ok) {
            alert(resultado.error || "No se pudieron guardar los permisos.");
            return;
        }

        alert(resultado.mensaje);

        await cargarPermisos(idusuario);

    } catch (error) {
        alert("Error al guardar los permisos.");
    }
}

cargarDatosPermiso();
</script>

<?php
require_once '../footer.php';
?>
