
<?php
require_once '../header.php';
?>

<style>
.usuario-container {
    padding: 25px;
}
.usuario-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
}
.usuario-titulo p {
    color: #92717D;
}
.usuario-card {
    background: #fff;
    padding: 22px;
    border-radius: 12px;
    margin-top: 20px;
    box-shadow: 0 3px 15px rgba(185,104,128,.10);
}
.btn-rosa {
    background: #B96880;
    color: white;
    border: none;
}
.btn-rosa:hover {
    background: #a6536d;
    color: white;
}
.tabla-usuarios thead {
    background: #f8e8ed;
    color: #945267;
}
.tabla-usuarios td {
    vertical-align: middle !important;
}
.estado-activo {
    background: #e4f5e9;
    color: #26834a;
    padding: 5px 10px;
    border-radius: 20px;
}
.estado-inactivo {
    background: #fce5e8;
    color: #bd5264;
    padding: 5px 10px;
    border-radius: 20px;
}
</style>

<div class="content-wrapper">
<section class="content-header">
    <div class="usuario-container">
        <div class="usuario-titulo">
            <h1><i class="fa fa-user-circle"></i> Gestión de Usuarios</h1>
            <p>Administra las cuentas de acceso al sistema.</p>
        </div>
    </div>
</section>

<section class="content">
<div class="usuario-container">

    <div class="usuario-card">
        <div class="row">
            <div class="col-md-8">
                <input type="text" id="buscarUsuario"
                       class="form-control"
                       placeholder="Buscar usuario por nombre o cuenta...">
            </div>
            <div class="col-md-4 text-right">
                <button class="btn btn-rosa" onclick="nuevoUsuario()">
                    <i class="fa fa-plus"></i> Nuevo usuario
                </button>
            </div>
        </div>
    </div>

    <div class="usuario-card">
        <div class="table-responsive">
            <table class="table table-bordered table-hover tabla-usuarios">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Usuario</th>
                        <th>Correo</th>
                        <th>Fecha de registro</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tablaUsuarios">
                    <tr>
                        <td colspan="7" class="text-center">Cargando usuarios...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
</section>
</div>

<!-- MODAL -->
<div class="modal fade" id="modalUsuario" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header" style="background:#B96880;color:white;">
                <button type="button" class="close" data-dismiss="modal"
                        style="color:white;opacity:1;">&times;</button>
                <h4 class="modal-title" id="tituloModal">Nuevo usuario</h4>
            </div>

            <div class="modal-body">
                <form id="formUsuario">
                    <input type="hidden" name="id" id="id">

                    <div class="form-group">
                        <label>Nombre completo *</label>
                        <input type="text" name="nombre" id="nombre"
                               class="form-control" required maxlength="150">
                    </div>

                    <div class="form-group">
                        <label>Nombre de usuario *</label>
                        <input type="text" name="usuario" id="usuario"
                               class="form-control" required maxlength="50">
                    </div>

                    <div class="form-group">
                        <label>Contraseña <span id="textoClave"></span></label>
                        <input type="password" name="clave" id="clave"
                               class="form-control" minlength="8"
                               autocomplete="new-password">
                        <small class="text-muted">
                            Para editar, déjala vacía si no deseas cambiarla.
                        </small>
                    </div>

                    <div class="form-group">
                        <label>Correo electrónico</label>
                        <input type="email" name="correo" id="correo"
                               class="form-control" maxlength="100">
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal">
                    Cancelar
                </button>
                <button class="btn btn-rosa" onclick="guardarUsuario()">
                    <i class="fa fa-save"></i> Guardar
                </button>
            </div>

        </div>
    </div>
</div>

<script>
const URL_USUARIO = "../ajax/usuario.php";
let usuarios = [];

function escaparUsuario(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, function(letra) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[letra];
    });
}

async function cargarUsuarios() {
    try {
        const respuesta = await fetch(URL_USUARIO + "?op=listar");
        usuarios = await respuesta.json();
        mostrarUsuarios(usuarios);
    } catch (error) {
        document.getElementById("tablaUsuarios").innerHTML =
            '<tr><td colspan="7" class="text-center text-danger">Error al cargar usuarios.</td></tr>';
    }
}

function mostrarUsuarios(datos) {
    const tabla = document.getElementById("tablaUsuarios");

    if (!Array.isArray(datos) || datos.length === 0) {
        tabla.innerHTML =
            '<tr><td colspan="7" class="text-center">No hay usuarios registrados.</td></tr>';
        return;
    }

    tabla.innerHTML = datos.map((u, i) => {
        const activo = u.estado === "Activo";

        return `
        <tr>
            <td>${i + 1}</td>
            <td>${escaparUsuario(u.nombre)}</td>
            <td>${escaparUsuario(u.usuario)}</td>
            <td>${escaparUsuario(u.correo)}</td>
            <td>${escaparUsuario(u.fecha_creacion)}</td>
            <td>
                <span class="${activo ? 'estado-activo' : 'estado-inactivo'}">
                    ${escaparUsuario(u.estado)}
                </span>
            </td>
            <td>
                <button class="btn btn-warning btn-xs"
                    onclick="editarUsuario(${Number(u.idusuario)})">
                    <i class="fa fa-pencil"></i>
                </button>

                <button class="btn ${activo ? 'btn-danger' : 'btn-success'} btn-xs"
                    onclick="cambiarEstadoUsuario(${Number(u.idusuario)}, '${activo ? 'Inactivo' : 'Activo'}')">
                    <i class="fa ${activo ? 'fa-ban' : 'fa-check'}"></i>
                </button>
            </td>
        </tr>`;
    }).join("");
}

function nuevoUsuario() {
    document.getElementById("formUsuario").reset();
    document.getElementById("id").value = "";
    document.getElementById("clave").required = true;
    document.getElementById("tituloModal").textContent = "Nuevo usuario";
    document.getElementById("textoClave").textContent = "*";
    $("#modalUsuario").modal("show");
}

function editarUsuario(id) {
    const u = usuarios.find(item => Number(item.idusuario) === Number(id));
    if (!u) return;

    document.getElementById("id").value = u.idusuario;
    document.getElementById("nombre").value = u.nombre;
    document.getElementById("usuario").value = u.usuario;
    document.getElementById("correo").value = u.correo ?? "";
    document.getElementById("clave").value = "";
    document.getElementById("clave").required = false;

    document.getElementById("tituloModal").textContent = "Editar usuario";
    document.getElementById("textoClave").textContent = "(opcional)";
    $("#modalUsuario").modal("show");
}

async function guardarUsuario() {
    const formulario = document.getElementById("formUsuario");

    if (!formulario.reportValidity()) return;

    const datos = new FormData(formulario);
    const id = datos.get("id");

    try {
        const respuesta = await fetch(
            URL_USUARIO + "?op=" + (id ? "editar" : "agregar"),
            {
                method: "POST",
                body: datos
            }
        );

        const resultado = await respuesta.json();

        if (!resultado.ok) {
            alert(resultado.error || "No se pudo guardar el usuario.");
            return;
        }

        $("#modalUsuario").modal("hide");
        alert(resultado.mensaje);
        cargarUsuarios();

    } catch (error) {
        alert("Error al guardar el usuario.");
    }
}

async function cambiarEstadoUsuario(id, estado) {
    if (!confirm("¿Deseas cambiar el estado de este usuario?")) return;

    const datos = new FormData();
    datos.append("id", id);
    datos.append("estado", estado);

    try {
        const respuesta = await fetch(URL_USUARIO + "?op=cambiarEstado", {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!resultado.ok) {
            alert(resultado.error || "No se pudo cambiar el estado.");
            return;
        }

        cargarUsuarios();

    } catch (error) {
        alert("Error al cambiar el estado.");
    }
}

document.getElementById("buscarUsuario").addEventListener("input", function() {
    const texto = this.value.toLowerCase();

    mostrarUsuarios(usuarios.filter(u =>
        String(u.nombre ?? "").toLowerCase().includes(texto) ||
        String(u.usuario ?? "").toLowerCase().includes(texto)
    ));
});

cargarUsuarios();
</script>

<?php
require_once '../footer.php';
?>
