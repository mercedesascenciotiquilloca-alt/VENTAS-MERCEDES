
<footer class="main-footer" style="
    background: #ffffff;
    border-top: 1px solid #eee5f2;
    color: #81758a;
    padding: 15px 20px;
    font-size: 13px;
">
    <div class="pull-right hidden-xs">
        <strong style="color: #8c65a0;">Sistema de Gestión</strong>
    </div>

    <strong style="color: #684477;">
        Copyright &copy; 2026
    </strong>
    <span>Todos los derechos reservados.</span>
</footer>

<script src="../public/js/jquery-3.1.1.min.js"></script>
<script src="../public/js/bootstrap.min.js"></script>
<script src="../public/js/app.min.js"></script>

<script src="../public/datatables/jquery.dataTables.min.js"></script>
<script src="../public/datatables/dataTables.buttons.min.js"></script>
<script src="../public/datatables/buttons.html5.min.js"></script>
<script src="../public/datatables/buttons.colVis.min.js"></script>
<script src="../public/datatables/jszip.min.js"></script>
<script src="../public/datatables/pdfmake.min.js"></script>
<script src="../public/datatables/vfs_fonts.js"></script>

<script src="../public/js/bootbox.min.js"></script>
<script src="../public/js/bootstrap-select.min.js"></script>

</div>
</body>
</html>
