
<?php
require_once __DIR__ . '/../../modelos/Consulta.php';

$consulta = new Consulta();
$ventas = $consulta->listarVentas();

require_once __DIR__ . '/../header.php';
?>

<style>
.consulta-container {
    padding: 25px;
}

.consulta-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
    margin-bottom: 7px;
}

.consulta-titulo p {
    color: #92717D;
    margin-bottom: 22px;
}

.consulta-panel {
    background: #fff;
    border-radius: 12px;
    padding: 22px;
    box-shadow: 0 3px 15px rgba(120, 50, 80, .08);
}

.consulta-panel h3 {
    color: #9F5972;
    font-size: 19px;
    font-weight: 700;
    margin-top: 0;
    margin-bottom: 18px;
}

.consulta-filtro {
    max-width: 350px;
    margin-bottom: 18px;
}

.consulta-filtro input {
    border: 1px solid #E8C4D1;
    border-radius: 8px;
    height: 40px;
}

.tabla-consulta {
    width: 100%;
    border-collapse: collapse;
}

.tabla-consulta th {
    background: #F8E5EC;
    color: #875267;
    padding: 13px 10px;
    text-align: left;
}

.tabla-consulta td {
    padding: 12px 10px;
    border-bottom: 1px solid #F1E2E8;
    color: #66515A;
}

.estado-registrada {
    background: #E3F5E8;
    color: #287A43;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.estado-anulada {
    background: #FCE4E4;
    color: #A52A2A;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.btn-detalle {
    background: #B96880;
    color: white;
    border: none;
    padding: 7px 12px;
    border-radius: 7px;
}

.btn-detalle:hover {
    background: #A65370;
    color: white;
}

.detalle-fila {
    display: none;
    background: #FFF8FA;
}

.detalle-fila td {
    padding: 18px !important;
}

.detalle-fila table {
    width: 100%;
    background: white;
}

.detalle-fila th {
    background: #F3DCE5;
}

.total-venta {
    color: #B96880;
    font-weight: bold;
}

.sin-registros {
    text-align: center;
    padding: 30px !important;
    color: #92717D !important;
}
</style>

<div class="content-wrapper">

    <section class="content-header consulta-container">

        <div class="consulta-titulo">
            <h1><i class="fa fa-search"></i> Consulta de ventas</h1>
            <p>Historial de ventas realizadas y detalle de productos vendidos.</p>
        </div>

        <div class="consulta-panel">

            <h3><i class="fa fa-shopping-bag"></i> Historial de ventas</h3>

            <div class="consulta-filtro">
                <input
                    type="text"
                    id="buscarVenta"
                    class="form-control"
                    placeholder="Buscar por cliente, comprobante o fecha...">
            </div>

            <div class="table-responsive">

                <table class="tabla-consulta" id="tablaVentas">

                    <thead>
                        <tr>
                            <th>N.º</th>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Comprobante</th>
                            <th>Total</th>
                            <th>Estado</th>
                            <th>Detalle</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (count($ventas) > 0): ?>

                        <?php foreach ($ventas as $venta): ?>

                            <?php
                            $detalles = $consulta->detalleVenta($venta['id']);
                            $filaDetalle = 'detalle_venta_' . $venta['id'];
                            ?>

                            <tr class="fila-venta">

                                <td><?php echo (int)$venta['id']; ?></td>

                                <td>
                                    <?php echo htmlspecialchars($venta['fecha_venta']); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($venta['cliente']); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($venta['comprobante'] ?: 'Sin comprobante'); ?>
                                </td>

                                <td class="total-venta">
                                    S/ <?php echo number_format((float)$venta['total'], 2); ?>
                                </td>

                                <td>
                                    <?php if ($venta['estado'] === 'Registrada'): ?>
                                        <span class="estado-registrada">Registrada</span>
                                    <?php else: ?>
                                        <span class="estado-anulada">Anulada</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <button
                                        type="button"
                                        class="btn-detalle"
                                        onclick="mostrarDetalleVenta('<?php echo $filaDetalle; ?>', this)">
                                        <i class="fa fa-eye"></i> Ver
                                    </button>
                                </td>

                            </tr>

                            <tr class="detalle-fila" id="<?php echo $filaDetalle; ?>">

                                <td colspan="7">

                                    <strong style="color:#9F5972;">
                                        Productos de la venta N.º <?php echo (int)$venta['id']; ?>
                                    </strong>

                                    <div class="table-responsive" style="margin-top:12px;">

                                        <table class="table table-bordered">

                                            <thead>
                                                <tr>
                                                    <th>Producto</th>
                                                    <th>Talla</th>
                                                    <th>Color</th>
                                                    <th>Cantidad</th>
                                                    <th>Precio unitario</th>
                                                    <th>Subtotal</th>
                                                </tr>
                                            </thead>

                                            <tbody>

                                            <?php foreach ($detalles as $detalle): ?>

                                                <tr>
                                                    <td>
                                                        <?php echo htmlspecialchars($detalle['articulo']); ?>
                                                    </td>

                                                    <td>
                                                        <?php echo htmlspecialchars($detalle['talla']); ?>
                                                    </td>

                                                    <td>
                                                        <?php echo htmlspecialchars($detalle['color']); ?>
                                                    </td>

                                                    <td>
                                                        <?php echo (int)$detalle['cantidad']; ?>
                                                    </td>

                                                    <td>
                                                        S/ <?php echo number_format((float)$detalle['precio_unitario'], 2); ?>
                                                    </td>

                                                    <td>
                                                        S/ <?php echo number_format((float)$detalle['subtotal'], 2); ?>
                                                    </td>
                                                </tr>

                                            <?php endforeach; ?>

                                            <?php if (count($detalles) === 0): ?>
                                                <tr>
                                                    <td colspan="6" class="text-center">
                                                        No hay productos registrados en esta venta.
                                                    </td>
                                                </tr>
                                            <?php endif; ?>

                                            </tbody>

                                        </table>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="7" class="sin-registros">
                                Todavía no hay ventas registradas.
                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>

<script>
function mostrarDetalleVenta(id, boton) {

    const fila = document.getElementById(id);

    if (fila.style.display === 'table-row') {

        fila.style.display = 'none';
        boton.innerHTML = '<i class="fa fa-eye"></i> Ver';

    } else {

        fila.style.display = 'table-row';
        boton.innerHTML = '<i class="fa fa-eye-slash"></i> Ocultar';

    }
}

document.getElementById('buscarVenta').addEventListener('input', function() {

    const busqueda = this.value.toLowerCase();

    const filas = document.querySelectorAll(
        '#tablaVentas tbody tr.fila-venta'
    );

    filas.forEach(function(fila) {

        const texto = fila.textContent.toLowerCase();
        const coincide = texto.includes(busqueda);

        fila.style.display = coincide ? '' : 'none';

        const siguiente = fila.nextElementSibling;

        if (siguiente && siguiente.classList.contains('detalle-fila')) {
            siguiente.style.display = 'none';
        }

    });

});
</script>

<?php require_once __DIR__ . '/../footer.php'; ?>
