
<?php
require 'header.php';
?>

<style>
.ropa-container { padding:25px; }

.ropa-titulo h1 {
    color:#B96880;
    font-size:27px;
    font-weight:700;
    margin:0 0 8px;
}
.ropa-titulo p { color:#92717D; }

.ropa-card {
    background:#fff;
    border:1px solid #F0DCE2;
    border-radius:14px;
    padding:20px;
    margin-bottom:20px;
    box-shadow:0 4px 15px rgba(185,104,128,.08);
    min-height:115px;
}
.ropa-card h4 { color:#92717D; font-size:13px; }
.ropa-card h2 { color:#684C56; font-weight:700; margin:5px 0; }

.ropa-icon {
    float:left;
    width:48px;
    height:48px;
    line-height:48px;
    text-align:center;
    border-radius:13px;
    margin-right:14px;
    background:#FCEEF1;
    color:#B96880;
    font-size:20px;
}

.btn-ropa {
    background:#E98FA8;
    border:none;
    color:white;
    border-radius:9px;
    padding:10px 17px;
    font-weight:600;
}
.btn-ropa:hover,.btn-ropa:focus {
    background:#B96880;
    color:white;
}

.ropa-panel {
    background:white;
    border:1px solid #F0DCE2;
    border-radius:15px;
    overflow:hidden;
    box-shadow:0 4px 18px rgba(185,104,128,.07);
}
.ropa-panel-header {
    padding:20px;
    border-bottom:1px solid #F0DCE2;
}
.ropa-panel-header h3 {
    color:#B96880;
    font-weight:700;
    margin:0;
}
.ropa-filtros {
    padding:18px 20px;
    background:#FFF8FA;
    border-bottom:1px solid #F0DCE2;
}

.ropa-container .form-control,
#modalArticulo .form-control {
    border-radius:8px !important;
    border:1px solid #E8CDD5 !important;
    box-shadow:none !important;
}
.ropa-container .form-control:focus,
#modalArticulo .form-control:focus {
    border-color:#E98FA8 !important;
}

.tabla-ropa {
    min-width:950px;
    margin-top:15px;
}
.tabla-ropa thead th {
    background:#FCEEF1;
    color:#98566B;
    padding:13px !important;
    font-size:12px;
    text-transform:uppercase;
}
.tabla-ropa tbody td {
    padding:13px !important;
    vertical-align:middle !important;
    color:#684C56;
}
.tabla-ropa tbody tr:hover { background:#FFF8FA; }

.codigo-ropa {
    background:#FCEEF1;
    color:#B96880;
    padding:5px 9px;
    border-radius:7px;
    font-weight:700;
}

.foto-prenda {
    width:58px;
    height:65px;
    object-fit:cover;
    border-radius:9px;
    border:1px solid #F0DCE2;
    background:#FFF8FA;
}
.foto-vacia {
    width:58px;
    height:65px;
    border-radius:9px;
    background:#FCEEF1;
    color:#B96880;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
}

.stock-normal { color:#4D9B72; font-weight:700; }
.stock-bajo { color:#D99442; font-weight:700; }
.stock-agotado { color:#D16C89; font-weight:700; }

.estado {
    display:inline-block;
    padding:6px 10px;
    border-radius:20px;
    font-size:11px;
    font-weight:700;
}
.estado-activo { background:#E5F5EC; color:#4C9A70; }
.estado-inactivo { background:#FAE5EC; color:#C56C88; }

.btn-editar-ropa,.btn-eliminar-ropa {
    border:none;
    width:34px;
    height:34px;
    border-radius:8px;
    margin-right:3px;
}
.btn-editar-ropa { background:#FCEEF1; color:#B96880; }
.btn-eliminar-ropa { background:#FAE5EC; color:#C56C88; }
.btn-editar-ropa:hover,.btn-eliminar-ropa:hover { opacity:.8; }

.modal-content {
    border-radius:15px !important;
    overflow:hidden;
    border:none !important;
}
.modal-header { background:#E98FA8; color:white; }
.modal-title { font-weight:700; }
.modal-body { padding:23px; }
.modal-body label { color:#684C56; }
.modal-header .close { color:white; opacity:1; }

.variante-fila {
    background:#FFF8FA;
    border:1px solid #F0DCE2;
    border-radius:10px;
    padding:12px;
    margin-bottom:10px;
}
.variante-fila .form-group { margin-bottom:5px; }
.variante-fila label { color:#98566B; font-size:12px; }

.btn-quitar {
    background:#FAE5EC;
    color:#C56C88;
    border:none;
    border-radius:7px;
    padding:8px 11px;
}
.btn-quitar:hover { background:#F5D5DE; }

.btn-agregar-variante {
    border:1px solid #E8CDD5;
    color:#B96880;
    background:#FFF8FA;
    border-radius:8px;
    padding:9px 13px;
}
.btn-agregar-variante:hover { background:#FCEEF1; }

.zona-fotografia {
    background:#FFF8FA;
    border:1px dashed #DDA7B7;
    border-radius:12px;
    padding:18px;
}
#vistaPreviaImagen {
    display:none;
    width:150px;
    height:170px;
    object-fit:cover;
    border-radius:12px;
    border:2px solid #F0DCE2;
    margin-top:12px;
}
.foto-icono-modal {
    width:150px;
    height:170px;
    border-radius:12px;
    background:#FCEEF1;
    color:#B96880;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:45px;
    margin-top:12px;
}
.texto-foto {
    color:#92717D;
    font-size:12px;
    margin-top:8px;
}

@media(max-width:768px) {
    .ropa-container { padding:15px; }
    .ropa-titulo .text-right {
        text-align:left;
        margin-top:15px;
    }
}
</style>

<div class="content-wrapper">
<section class="content">
<div class="ropa-container">

    <div class="row ropa-titulo">
        <div class="col-md-8">
            <h1><i class="fa fa-shopping-bag"></i> Inventario de ropa</h1>
            <p>Administra tus prendas, fotografías, tallas, colores y existencias.</p>
        </div>
        <div class="col-md-4 text-right">
            <button class="btn btn-ropa" onclick="abrirNuevo()">
                <i class="fa fa-plus"></i> Nueva prenda
            </button>
        </div>
    </div>

    <!-- RESUMEN -->
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="ropa-card">
                <div class="ropa-icon"><i class="fa fa-cubes"></i></div>
                <h4>Total de prendas</h4>
                <h2 id="totalArticulos">0</h2>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="ropa-card">
                <div class="ropa-icon"><i class="fa fa-tags"></i></div>
                <h4>Categorías</h4>
                <h2 id="totalCategorias">0</h2>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="ropa-card">
                <div class="ropa-icon"><i class="fa fa-archive"></i></div>
                <h4>Unidades disponibles</h4>
                <h2 id="totalStock">0</h2>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="ropa-card">
                <div class="ropa-icon"><i class="fa fa-exclamation-triangle"></i></div>
                <h4>Prendas con stock bajo</h4>
                <h2 id="totalStockBajo">0</h2>
            </div>
        </div>
    </div>

    <!-- INVENTARIO -->
    <div class="ropa-panel">
        <div class="ropa-panel-header">
            <h3><i class="fa fa-list"></i> Gestión de prendas</h3>
            <p class="text-muted">Consulta y administra los productos de tu inventario.</p>
        </div>

        <div class="ropa-filtros">
            <div class="row">
                <div class="col-md-5">
                    <label>Buscar prenda</label>
                    <input type="text" id="buscarArticulo"
                        class="form-control"
                        placeholder="Código o nombre de la prenda...">
                </div>

                <div class="col-md-4">
                    <label>Categoría</label>
                    <select id="filtroCategoria" class="form-control">
                        <option value="">Todas las categorías</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label>Estado</label>
                    <select id="filtroEstado" class="form-control">
                        <option value="">Todos</option>
                        <option value="Activo">Activo</option>
                        <option value="Inactivo">Inactivo</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="table-responsive" style="padding:0 20px 20px;">
            <table class="table tabla-ropa">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Fotografía</th>
                        <th>Código</th>
                        <th>Prenda</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Variantes</th>
                        <th>Stock</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tablaArticulos">
                    <tr>
                        <td colspan="10" class="text-center">Cargando inventario...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
</section>
</div>

<!-- MODAL DE PRENDA -->
<div class="modal fade" id="modalArticulo" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">
                    <i class="fa fa-shopping-bag"></i>
                    <span id="tituloModal">Nueva prenda</span>
                </h4>
            </div>

            <form id="formArticulo" enctype="multipart/form-data">
                <div class="modal-body">

                    <input type="hidden" id="id" name="id">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Código de la prenda</label>
                                <input type="text" id="codigo" name="codigo"
                                    class="form-control" placeholder="Ej. POL001"
                                    maxlength="50" required>
                            </div>
                        </div>

                        <div class="col-md-8">
                            <div class="form-group">
                                <label>Nombre de la prenda</label>
                                <input type="text" id="nombre" name="nombre"
                                    class="form-control"
                                    placeholder="Ej. Polo básico de algodón" required>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Categoría</label>
                                <select id="categoria" name="categoria"
                                    class="form-control" required>
                                    <option value="">Selecciona una categoría</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Precio de venta (S/)</label>
                                <input type="number" id="precio" name="precio"
                                    class="form-control" min="0" step="0.01" required>
                            </div>
                        </div>

                        <!-- FOTOGRAFÍA -->
                        <div class="col-md-12">
                            <hr>
                            <h4 style="color:#B96880;font-weight:700;">
                                <i class="fa fa-camera"></i> Fotografía de la prenda
                            </h4>

                            <div class="zona-fotografia">
                                <div class="form-group">
                                    <label for="imagen">Seleccionar fotografía</label>
                                    <input type="file" id="imagen" name="imagen"
                                        class="form-control"
                                        accept="image/jpeg,image/png,image/webp">

                                    <p class="texto-foto">
                                        Formatos permitidos: JPG, PNG y WEBP. Tamaño máximo: 5 MB.
                                        La fotografía es opcional.
                                    </p>
                                </div>

                                <div id="contenedorVistaPrevia">
                                    <div id="fotoSinSeleccion" class="foto-icono-modal">
                                        <i class="fa fa-picture-o"></i>
                                    </div>
                                    <img id="vistaPreviaImagen" src="" alt="Vista previa de la prenda">
                                </div>
                            </div>
                        </div>

                        <!-- VARIANTES -->
                        <div class="col-md-12">
                            <hr>
                            <h4 style="color:#B96880;font-weight:700;">
                                <i class="fa fa-th-large"></i>
                                Inventario por tallas y colores
                            </h4>
                            <p class="text-muted">
                                Agrega una fila por cada combinación de talla y color.
                            </p>
                        </div>

                        <div class="col-md-12" id="contenedorVariantes"></div>

                        <div class="col-md-12">
                            <button type="button" class="btn-agregar-variante"
                                onclick="agregarVariante()">
                                <i class="fa fa-plus"></i> Agregar talla y color
                            </button>
                        </div>

                        <div class="col-md-12">
                            <hr>
                            <div class="form-group">
                                <label>Estado</label>
                                <select id="estado" name="estado" class="form-control">
                                    <option value="Activo">Activo</option>
                                    <option value="Inactivo">Inactivo</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-ropa">
                        <i class="fa fa-save"></i> Guardar prenda
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const URL_ARTICULO = "../ajax/articulo.php";
const URL_CATEGORIA = "../ajax/categoria.php";

let listaArticulos = [];
let listaCategorias = [];
let imagenTemporal = null;

function escapar(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[caracter]);
}

/* CARGAR CATEGORÍAS */
async function cargarCategorias() {
    const select = document.getElementById("categoria");
    const filtro = document.getElementById("filtroCategoria");

    try {
        const respuesta = await fetch(URL_CATEGORIA);
        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudieron cargar las categorías.");
        }

        listaCategorias = resultado.data || [];

        select.innerHTML = '<option value="">Selecciona una categoría</option>';
        filtro.innerHTML = '<option value="">Todas las categorías</option>';

        listaCategorias.forEach(categoria => {
            const opcion1 = document.createElement("option");
            opcion1.value = categoria.id;
            opcion1.textContent = categoria.nombre;
            select.appendChild(opcion1);

            const opcion2 = document.createElement("option");
            opcion2.value = categoria.id;
            opcion2.textContent = categoria.nombre;
            filtro.appendChild(opcion2);
        });

        document.getElementById("totalCategorias").textContent = listaCategorias.length;

    } catch (error) {
        console.error(error);
        alert("No se pudieron cargar las categorías. Revisa ajax/categoria.php.");
        throw error;
    }
}

/* VISTA PREVIA DE FOTOGRAFÍA */
function mostrarVistaPrevia(ruta) {
    const imagen = document.getElementById("vistaPreviaImagen");
    const sinFoto = document.getElementById("fotoSinSeleccion");

    if (ruta) {
        imagen.src = ruta;
        imagen.style.display = "block";
        sinFoto.style.display = "none";
    } else {
        imagen.removeAttribute("src");
        imagen.style.display = "none";
        sinFoto.style.display = "flex";
    }
}

document.getElementById("imagen").addEventListener("change", function() {
    const archivo = this.files[0];

    if (!archivo) {
        return;
    }

    const formatos = ["image/jpeg", "image/png", "image/webp"];

    if (!formatos.includes(archivo.type)) {
        alert("Selecciona una imagen JPG, PNG o WEBP.");
        this.value = "";
        return;
    }

    if (archivo.size > 5 * 1024 * 1024) {
        alert("La fotografía no debe superar los 5 MB.");
        this.value = "";
        return;
    }

    if (imagenTemporal) {
        URL.revokeObjectURL(imagenTemporal);
    }

    imagenTemporal = URL.createObjectURL(archivo);
    mostrarVistaPrevia(imagenTemporal);
});

/* AGREGAR VARIANTES */
function agregarVariante(datos = {}) {
    const contenedor = document.getElementById("contenedorVariantes");
    const fila = document.createElement("div");

    fila.className = "variante-fila";

    fila.innerHTML = `
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label>Talla</label>
                    <select class="form-control talla-variante" required>
                        <option value="">Seleccionar</option>
                        <option value="XS">XS</option>
                        <option value="S">S</option>
                        <option value="M">M</option>
                        <option value="L">L</option>
                        <option value="XL">XL</option>
                        <option value="XXL">XXL</option>
                        <option value="Única">Única</option>
                    </select>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label>Color</label>
                    <input type="text" class="form-control color-variante"
                        placeholder="Ej. Negro" maxlength="50" required>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label>Cantidad</label>
                    <input type="number" class="form-control stock-variante"
                        min="0" step="1" value="0" required>
                </div>
            </div>

            <div class="col-sm-2">
                <label>&nbsp;</label>
                <button type="button" class="btn-quitar btn-block" title="Quitar variante">
                    <i class="fa fa-trash"></i>
                </button>
            </div>
        </div>
    `;

    const talla = fila.querySelector(".talla-variante");
    const tallaGuardada = String(datos.talla || "");

    if (tallaGuardada &&
        !Array.from(talla.options).some(opcion => opcion.value === tallaGuardada)) {
        const opcion = document.createElement("option");
        opcion.value = tallaGuardada;
        opcion.textContent = tallaGuardada;
        talla.appendChild(opcion);
    }

    talla.value = tallaGuardada;
    fila.querySelector(".color-variante").value = datos.color || "";
    fila.querySelector(".stock-variante").value =
        datos.stock !== undefined ? datos.stock : 0;

    fila.querySelector(".btn-quitar").addEventListener("click", () => {
        if (contenedor.children.length === 1) {
            alert("Debes mantener al menos una variante.");
            return;
        }
        fila.remove();
    });

    contenedor.appendChild(fila);
}

/* OBTENER VARIANTES */
function obtenerVariantes() {
    const filas = document.querySelectorAll(".variante-fila");
    const variantes = [];

    filas.forEach(fila => {
        variantes.push({
            talla: fila.querySelector(".talla-variante").value,
            color: fila.querySelector(".color-variante").value.trim(),
            stock: Number(fila.querySelector(".stock-variante").value)
        });
    });

    return variantes;
}

/* LISTAR ARTÍCULOS */
async function listar() {
    const tabla = document.getElementById("tablaArticulos");

    try {
        const respuesta = await fetch(URL_ARTICULO);
        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo cargar el inventario.");
        }

        listaArticulos = resultado.data || [];
        actualizarResumen();
        mostrarArticulos();

    } catch (error) {
        console.error(error);
        tabla.innerHTML = `
            <tr>
                <td colspan="10" class="text-center text-danger">
                    No se pudo cargar el inventario. Revisa la conexión.
                </td>
            </tr>
        `;
    }
}

/* RESUMEN */
function actualizarResumen() {
    const stock = listaArticulos.reduce(
        (total, articulo) => total + Number(articulo.stock || 0), 0
    );

    const stockBajo = listaArticulos.filter(
        articulo => Number(articulo.stock || 0) <= 5
    ).length;

    document.getElementById("totalArticulos").textContent = listaArticulos.length;
    document.getElementById("totalStock").textContent = stock;
    document.getElementById("totalStockBajo").textContent = stockBajo;
}

/* MOSTRAR TABLA */
function mostrarArticulos() {
    const busqueda = document.getElementById("buscarArticulo").value.toLowerCase().trim();
    const categoria = document.getElementById("filtroCategoria").value;
    const estado = document.getElementById("filtroEstado").value;

    const filtrados = listaArticulos.filter(articulo => {
        const codigo = String(articulo.codigo || "").toLowerCase();
        const nombre = String(articulo.nombre || "").toLowerCase();

        const coincideBusqueda = codigo.includes(busqueda) || nombre.includes(busqueda);
        const coincideCategoria = !categoria ||
            String(articulo.categoria_id) === String(categoria);
        const coincideEstado = !estado || articulo.estado === estado;

        return coincideBusqueda && coincideCategoria && coincideEstado;
    });

    const tabla = document.getElementById("tablaArticulos");
    tabla.innerHTML = "";

    if (filtrados.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="10" class="text-center"
                    style="padding:35px;color:#B18C99;">
                    <i class="fa fa-search fa-2x"></i>
                    <p>No se encontraron prendas.</p>
                </td>
            </tr>
        `;
        return;
    }

    filtrados.forEach(articulo => {
        const stock = Number(articulo.stock || 0);
        const precio = Number(articulo.precio || 0);

        const claseStock = stock === 0
            ? "stock-agotado"
            : stock <= 5 ? "stock-bajo" : "stock-normal";

        const estadoHTML = articulo.estado === "Activo"
            ? '<span class="estado estado-activo">Activo</span>'
            : '<span class="estado estado-inactivo">Inactivo</span>';

        const fotografia = articulo.imagen
            ? `<img src="${escapar(articulo.imagen)}"
                    class="foto-prenda"
                    alt="Fotografía de ${escapar(articulo.nombre)}"
                    onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
               <div class="foto-vacia" style="display:none;">
                    <i class="fa fa-picture-o"></i>
               </div>`
            : `<div class="foto-vacia"><i class="fa fa-picture-o"></i></div>`;

        const fila = document.createElement("tr");

        fila.innerHTML = `
            <td>#${escapar(articulo.id)}</td>
            <td>${fotografia}</td>
            <td><span class="codigo-ropa">${escapar(articulo.codigo)}</span></td>
            <td><strong>${escapar(articulo.nombre)}</strong></td>
            <td>${escapar(articulo.categoria)}</td>
            <td>S/ ${precio.toFixed(2)}</td>
            <td>${(articulo.variantes || []).length}</td>
            <td><span class="${claseStock}">${stock}</span></td>
            <td>${estadoHTML}</td>
            <td>
                <button class="btn-editar-ropa" title="Editar" type="button">
                    <i class="fa fa-pencil"></i>
                </button>
                <button class="btn-eliminar-ropa" title="Eliminar" type="button">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        `;

        fila.querySelector(".btn-editar-ropa").addEventListener(
            "click", () => editarArticulo(articulo.id)
        );

        fila.querySelector(".btn-eliminar-ropa").addEventListener(
            "click", () => eliminarArticulo(articulo.id)
        );

        tabla.appendChild(fila);
    });
}

/* NUEVA PRENDA */
function abrirNuevo() {
    if (listaCategorias.length === 0) {
        alert("Primero debes registrar categorías en el sistema.");
        return;
    }

    document.getElementById("formArticulo").reset();
    document.getElementById("id").value = "";
    document.getElementById("tituloModal").textContent = "Nueva prenda";
    document.getElementById("contenedorVariantes").innerHTML = "";

    mostrarVistaPrevia(null);
    agregarVariante();

    $("#modalArticulo").modal("show");
}

/* EDITAR PRENDA */
function editarArticulo(id) {
    const articulo = listaArticulos.find(
        elemento => Number(elemento.id) === Number(id)
    );

    if (!articulo) {
        alert("No se encontró la prenda.");
        return;
    }

    document.getElementById("formArticulo").reset();

    document.getElementById("id").value = articulo.id;
    document.getElementById("codigo").value = articulo.codigo;
    document.getElementById("nombre").value = articulo.nombre;
    document.getElementById("categoria").value = articulo.categoria_id;
    document.getElementById("precio").value = articulo.precio;
    document.getElementById("estado").value = articulo.estado;
    document.getElementById("tituloModal").textContent = "Editar prenda";

    // Mostrar fotografía guardada, si existe.
    mostrarVistaPrevia(articulo.imagen || null);

    const contenedor = document.getElementById("contenedorVariantes");
    contenedor.innerHTML = "";

    if (articulo.variantes && articulo.variantes.length > 0) {
        articulo.variantes.forEach(variante => agregarVariante(variante));
    } else {
        agregarVariante();
    }

    $("#modalArticulo").modal("show");
}

/* GUARDAR O ACTUALIZAR */
document.getElementById("formArticulo").addEventListener("submit", async function(evento) {
    evento.preventDefault();

    const variantes = obtenerVariantes();

    if (variantes.length === 0) {
        alert("Agrega al menos una combinación de talla y color.");
        return;
    }

    for (const variante of variantes) {
        if (!variante.talla || !variante.color) {
            alert("Completa la talla y el color de todas las variantes.");
            return;
        }

        if (!Number.isInteger(variante.stock) || variante.stock < 0) {
            alert("Las cantidades deben ser números enteros iguales o mayores a cero.");
            return;
        }
    }

    const datos = new FormData(this);
    const id = document.getElementById("id").value;

    datos.set("accion", id ? "editar" : "agregar");
    datos.set("variantes", JSON.stringify(variantes));

    const boton = this.querySelector('[type="submit"]');
    boton.disabled = true;

    try {
        const respuesta = await fetch(URL_ARTICULO, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo guardar la prenda.");
        }

        alert(resultado.mensaje);
        $("#modalArticulo").modal("hide");

        await listar();

    } catch (error) {
        console.error(error);
        alert(error.message || "No se pudo guardar la prenda.");
    } finally {
        boton.disabled = false;
    }
});

/* ELIMINAR PRENDA */
async function eliminarArticulo(id) {
    if (!confirm("¿Deseas eliminar esta prenda y sus variantes?")) {
        return;
    }

    const datos = new FormData();
    datos.append("accion", "eliminar");
    datos.append("id", id);

    try {
        const respuesta = await fetch(URL_ARTICULO, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo eliminar la prenda.");
        }

        alert(resultado.mensaje);
        await listar();

    } catch (error) {
        console.error(error);
        alert(error.message || "No se pudo eliminar la prenda.");
    }
}

/* FILTROS */
document.getElementById("buscarArticulo").addEventListener("input", mostrarArticulos);
document.getElementById("filtroCategoria").addEventListener("change", mostrarArticulos);
document.getElementById("filtroEstado").addEventListener("change", mostrarArticulos);

/* INICIAR */
async function iniciarInventario() {
    try {
        await cargarCategorias();
        await listar();
    } catch (error) {
        document.getElementById("tablaArticulos").innerHTML = `
            <tr>
                <td colspan="10" class="text-center text-danger">
                    No se pudo iniciar el inventario. Revisa el módulo de categorías.
                </td>
            </tr>
        `;
    }
}

iniciarInventario();
</script>

<?php
require 'footer.php';
?>
