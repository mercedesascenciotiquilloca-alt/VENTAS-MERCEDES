
<?php
require_once 'header.php';
?>

<style>
.ayuda-container {
    padding: 25px;
}

.ayuda-titulo h1 {
    color: #B96880;
    font-size: 28px;
    font-weight: 700;
}

.ayuda-titulo p {
    color: #92717D;
    margin-bottom: 25px;
}

.ayuda-card {
    background: white;
    border-radius: 12px;
    padding: 22px;
    margin-bottom: 18px;
    box-shadow: 0 3px 15px rgba(120,50,80,.08);
    border-left: 5px solid #C77F98;
}

.ayuda-card h3 {
    color: #A65370;
    font-size: 19px;
    font-weight: bold;
    margin-top: 0;
}

.ayuda-card p, .ayuda-card li {
    color: #715B64;
    line-height: 1.8;
}

.ayuda-numero {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    background: #F8E5EC;
    color: #A65370;
    border-radius: 50%;
    font-weight: bold;
    margin-right: 8px;
}
</style>

<div class="content-wrapper">

    <section class="content-header ayuda-container">

        <div class="ayuda-titulo">
            <h1><i class="fa fa-question-circle"></i> Centro de ayuda</h1>
            <p>Guía para utilizar correctamente el sistema de gestión VENTAS MERCEDES.</p>
        </div>

        <div class="ayuda-card">
            <h3><i class="fa fa-home"></i> 1. Escritorio</h3>
            <p>
                En esta sección encontrarás la pantalla principal del sistema,
                desde donde puedes acceder a los diferentes módulos de gestión.
            </p>
        </div>

        <div class="ayuda-card">
            <h3><i class="fa fa-tags"></i> 2. Almacén</h3>
            <p>
                Permite administrar los productos de ropa, sus categorías,
                tallas, colores, precios y existencias disponibles.
            </p>
            <ul>
                <li>Registrar nuevos productos.</li>
                <li>Consultar el inventario.</li>
                <li>Organizar productos por categorías.</li>
                <li>Controlar las existencias por talla y color.</li>
            </ul>
        </div>

        <div class="ayuda-card">
            <h3><i class="fa fa-shopping-cart"></i> 3. Compras</h3>
            <p>
                Permite registrar las compras realizadas a los proveedores
                y aumentar el stock de los productos.
            </p>
            <ul>
                <li>Registrar proveedores.</li>
                <li>Ingresar nuevas compras.</li>
                <li>Consultar el historial de compras.</li>
            </ul>
        </div>

        <div class="ayuda-card">
            <h3><i class="fa fa-shopping-bag"></i> 4. Ventas</h3>
            <p>
                Permite registrar las ventas realizadas a los clientes
                y controlar la salida de productos del inventario.
            </p>
            <ul>
                <li>Registrar clientes.</li>
                <li>Realizar nuevas ventas.</li>
                <li>Consultar las ventas registradas.</li>
                <li>Verificar cantidades y precios.</li>
            </ul>
        </div>

        <div class="ayuda-card">
            <h3><i class="fa fa-lock"></i> 5. Acceso</h3>
            <p>
                Permite administrar los usuarios del sistema y configurar
                los permisos de acceso a los diferentes módulos.
            </p>
            <ul>
                <li>Registrar usuarios.</li>
                <li>Editar información de usuarios.</li>
                <li>Activar o desactivar usuarios.</li>
                <li>Asignar permisos por módulo.</li>
            </ul>
        </div>

        <div class="ayuda-card">
            <h3><i class="fa fa-lightbulb-o"></i> Recomendaciones</h3>
            <ul>
                <li>Verifica los datos antes de registrar una compra o venta.</li>
                <li>Mantén actualizado el inventario.</li>
                <li>Registra correctamente a tus clientes y proveedores.</li>
                <li>Utiliza usuarios autorizados para ingresar al sistema.</li>
            </ul>
        </div>

    </section>

</div>

<?php require_once 'footer.php'; ?>
