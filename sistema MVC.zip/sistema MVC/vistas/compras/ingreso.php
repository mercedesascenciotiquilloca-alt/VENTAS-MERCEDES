
<?php
require_once __DIR__ . "/../header.php";
?>

<style>
.compra-container { padding: 25px; }
.compra-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
}
.compra-titulo p { color: #92717D; }
.compra-card {
    background: #fff;
    border: 1px solid #f3e4ea;
    border-radius: 12px;
    padding: 22px;
    margin-bottom: 22px;
    box-shadow: 0 3px 15px rgba(185,104,128,.08);
}
.compra-card h4 {
    color: #805466;
    font-weight: 700;
    margin-top: 0;
    margin-bottom: 18px;
}
.compra-card .form-control { border-radius: 7px; }
.btn-compra {
    background: #B96880;
    color: white;
    border: 0;
    border-radius: 7px;
    padding: 10px 17px;
}
.btn-compra:hover { background: #a6536c; color: white; }
.tabla-compra th {
    background: #f9edf1;
    color: #805466;
}
.tabla-compra td, .tabla-compra th {
    padding: 11px;
    vertical-align: middle !important;
}
.total-compra {
    text-align: right;
    color: #B96880;
    font-size: 23px;
    font-weight: bold;
    margin: 18px 0;
}
</style>

<div class="content-wrapper">

    <section class="content-header">
        <div class="compra-container compra-titulo">
            <h1><i class="fa fa-shopping-cart"></i> Ingreso de Compras</h1>
            <p>Registra las compras de mercadería y actualiza el inventario.</p>
        </div>
    </section>

    <section class="content compra-container">

        <div class="compra-card">
            <h4><i class="fa fa-file-text-o"></i> Datos de la compra</h4>

            <div class="row">
                <div class="col-md-6">
                    <label>Proveedor *</label>
                    <select id="proveedorCompra" class="form-control">
                        <option value="">Seleccionar proveedor</option>
                    </select>
                </div>

                <div class="col-md-6">
                    <label>Número de comprobante</label>
                    <input type="text" id="comprobanteCompra"
                           class="form-control" maxlength="50"
                           placeholder="Ej. F001-000125">
                </div>
            </div>
        </div>

        <div class="compra-card">
            <h4><i class="fa fa-plus-circle"></i> Agregar productos</h4>

            <div class="row">
                <div class="col-md-6">
                    <label>Prenda, talla y color *</label>
                    <select id="varianteCompra" class="form-control">
                        <option value="">Seleccionar producto</option>
                    </select>
                </div>

                <div class="col-md-2">
                    <label>Cantidad *</label>
                    <input type="number" id="cantidadCompra"
                           class="form-control" min="1" value="1">
                </div>

                <div class="col-md-2">
                    <label>Costo unitario (S/) *</label>
                    <input type="number" id="costoCompra"
                           class="form-control" min="0.01"
                           step="0.01" placeholder="0.00">
                </div>

                <div class="col-md-2">
                    <label>&nbsp;</label>
                    <button type="button" class="btn-compra"
                            style="width:100%" onclick="agregarProducto()">
                        <i class="fa fa-plus"></i> Agregar
                    </button>
                </div>
            </div>

            <p id="stockDisponible" style="color:#92717D;margin-top:12px;"></p>
        </div>

        <div class="compra-card">
            <h4><i class="fa fa-list"></i> Detalle de la compra</h4>

            <div id="mensajeCompra"></div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover tabla-compra">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Talla</th>
                            <th>Color</th>
                            <th>Cantidad</th>
                            <th>Costo unitario</th>
                            <th>Subtotal</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody id="detalleCompra">
                        <tr>
                            <td colspan="7" class="text-center">
                                Agrega productos a la compra.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="total-compra">
                Total: S/ <span id="totalCompra">0.00</span>
            </div>

            <div style="text-align:right;">
                <button type="button" class="btn-compra"
                        onclick="registrarCompra()">
                    <i class="fa fa-save"></i> Registrar compra
                </button>
            </div>
        </div>

        <div class="compra-card">
            <h4><i class="fa fa-history"></i> Historial de compras</h4>

            <div class="table-responsive">
                <table class="table table-bordered table-hover tabla-compra">
                    <thead>
                        <tr>
                            <th>N.º</th>
                            <th>Fecha</th>
                            <th>Proveedor</th>
                            <th>Comprobante</th>
                            <th>Total</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody id="historialCompras">
                        <tr>
                            <td colspan="6" class="text-center">Cargando...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>

<script>
const URL_COMPRA = "../ajax/compra.php";

let variantesDisponibles = [];
let productosCompra = [];

const proveedorCompra = document.getElementById("proveedorCompra");
const varianteCompra = document.getElementById("varianteCompra");
const cantidadCompra = document.getElementById("cantidadCompra");
const costoCompra = document.getElementById("costoCompra");
const detalleCompra = document.getElementById("detalleCompra");
const mensajeCompra = document.getElementById("mensajeCompra");

function escaparHTML(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[caracter]);
}

function mostrarMensajeCompra(mensaje, tipo = "success") {
    mensajeCompra.innerHTML = "";

    const alerta = document.createElement("div");
    alerta.className = "alert alert-" + tipo;
    alerta.textContent = mensaje;

    mensajeCompra.appendChild(alerta);
}

async function cargarDatosCompra() {
    try {
        const respuesta = await fetch(URL_COMPRA + "?accion=datos");
        const resultado = await respuesta.json();

        if (!resultado.success) {
            throw new Error(resultado.mensaje);
        }

        proveedorCompra.innerHTML =
            '<option value="">Seleccionar proveedor</option>';

        resultado.data.proveedores.forEach(proveedor => {
            const opcion = document.createElement("option");
            opcion.value = proveedor.id;
            opcion.textContent = proveedor.nombre;
            proveedorCompra.appendChild(opcion);
        });

        variantesDisponibles = resultado.data.variantes;

        varianteCompra.innerHTML =
            '<option value="">Seleccionar producto</option>';

        variantesDisponibles.forEach(variante => {
            const opcion = document.createElement("option");
            opcion.value = variante.variante_id;
            opcion.textContent =
                variante.codigo + " - " + variante.nombre +
                " | Talla: " + variante.talla +
                " | Color: " + variante.color +
                " | Stock: " + variante.stock;

            varianteCompra.appendChild(opcion);
        });

    } catch (error) {
        mostrarMensajeCompra(error.message, "danger");
    }
}

varianteCompra.addEventListener("change", function() {
    const variante = variantesDisponibles.find(
        item => String(item.variante_id) === this.value
    );

    document.getElementById("stockDisponible").textContent = variante
        ? "Stock actual: " + variante.stock + " unidades"
        : "";
});

function agregarProducto() {
    const id = parseInt(varianteCompra.value);
    const cantidad = parseInt(cantidadCompra.value);
    const costo = parseFloat(costoCompra.value);

    const variante = variantesDisponibles.find(
        item => parseInt(item.variante_id) === id
    );

    if (!variante) {
        mostrarMensajeCompra("Selecciona una prenda, talla y color.", "warning");
        return;
    }

    if (!Number.isInteger(cantidad) || cantidad <= 0) {
        mostrarMensajeCompra("Ingresa una cantidad válida.", "warning");
        return;
    }

    if (!Number.isFinite(costo) || costo <= 0) {
        mostrarMensajeCompra("Ingresa un costo unitario válido.", "warning");
        return;
    }

    productosCompra.push({
        variante_id: id,
        nombre: variante.nombre,
        talla: variante.talla,
        color: variante.color,
        cantidad: cantidad,
        costo_unitario: costo
    });

    dibujarDetalle();

    varianteCompra.value = "";
    cantidadCompra.value = 1;
    costoCompra.value = "";
    document.getElementById("stockDisponible").textContent = "";
    mensajeCompra.innerHTML = "";
}

function dibujarDetalle() {
    detalleCompra.innerHTML = "";
    let total = 0;

    if (productosCompra.length === 0) {
        detalleCompra.innerHTML = `
            <tr><td colspan="7" class="text-center">
                Agrega productos a la compra.
            </td></tr>`;
    }

    productosCompra.forEach((producto, indice) => {
        const subtotal = producto.cantidad * producto.costo_unitario;
        total += subtotal;

        const fila = document.createElement("tr");

        const valores = [
            producto.nombre,
            producto.talla,
            producto.color,
            producto.cantidad,
            "S/ " + producto.costo_unitario.toFixed(2),
            "S/ " + subtotal.toFixed(2)
        ];

        valores.forEach(valor => {
            const celda = document.createElement("td");
            celda.textContent = valor;
            fila.appendChild(celda);
        });

        const celdaAccion = document.createElement("td");
        const boton = document.createElement("button");
        boton.type = "button";
        boton.className = "btn btn-danger btn-sm";
        boton.innerHTML = '<i class="fa fa-trash"></i>';
        boton.title = "Quitar producto";
        boton.onclick = () => {
            productosCompra.splice(indice, 1);
            dibujarDetalle();
        };

        celdaAccion.appendChild(boton);
        fila.appendChild(celdaAccion);
        detalleCompra.appendChild(fila);
    });

    document.getElementById("totalCompra").textContent = total.toFixed(2);
}

async function registrarCompra() {
    if (!proveedorCompra.value) {
        mostrarMensajeCompra("Selecciona un proveedor.", "warning");
        return;
    }

    if (productosCompra.length === 0) {
        mostrarMensajeCompra("Agrega al menos un producto.", "warning");
        return;
    }

    if (!confirm("¿Deseas registrar esta compra y actualizar el inventario?")) {
        return;
    }

    const datos = new FormData();
    datos.append("accion", "registrar");
    datos.append("proveedor_id", proveedorCompra.value);
    datos.append("comprobante",
        document.getElementById("comprobanteCompra").value);
    datos.append("detalles", JSON.stringify(productosCompra));

    try {
        const respuesta = await fetch(URL_COMPRA, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo registrar la compra.");
        }

        mostrarMensajeCompra(
            resultado.mensaje + " Número de compra: " + resultado.data.id
        );

        productosCompra = [];
        proveedorCompra.value = "";
        document.getElementById("comprobanteCompra").value = "";
        dibujarDetalle();

        await cargarDatosCompra();
        await cargarHistorialCompras();

    } catch (error) {
        mostrarMensajeCompra(error.message, "danger");
    }
}

async function cargarHistorialCompras() {
    const tabla = document.getElementById("historialCompras");

    try {
        const respuesta = await fetch(URL_COMPRA + "?accion=listar");
        const resultado = await respuesta.json();

        if (!resultado.success) {
            throw new Error(resultado.mensaje);
        }

        tabla.innerHTML = "";

        if (!resultado.data.length) {
            tabla.innerHTML = `
                <tr><td colspan="6" class="text-center">
                    Todavía no hay compras registradas.
                </td></tr>`;
            return;
        }

        resultado.data.forEach(compra => {
            const fila = document.createElement("tr");

            const valores = [
                compra.id,
                compra.fecha_compra,
                compra.proveedor,
                compra.comprobante || "-",
                "S/ " + Number(compra.total).toFixed(2),
                compra.estado
            ];

            valores.forEach(valor => {
                const celda = document.createElement("td");
                celda.textContent = valor;
                fila.appendChild(celda);
            });

            tabla.appendChild(fila);
        });

    } catch (error) {
        tabla.innerHTML = `
            <tr><td colspan="6" class="text-center text-danger">
                ${escaparHTML(error.message)}
            </td></tr>`;
    }
}

cargarDatosCompra();
cargarHistorialCompras();
</script>

<?php
require_once __DIR__ . "/../footer.php";
?>
