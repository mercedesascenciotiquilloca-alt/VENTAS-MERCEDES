
<?php
require_once __DIR__ . "/../header.php";
?>

<style>
.proveedor-container {
    padding: 25px;
}

.proveedor-titulo h1 {
    color: #B96880;
    font-size: 27px;
    font-weight: 700;
    margin-bottom: 8px;
}

.proveedor-titulo p {
    color: #92717D;
}

.proveedor-card {
    background: #fff;
    border-radius: 12px;
    padding: 22px;
    box-shadow: 0 3px 15px rgba(185,104,128,.10);
    border: 1px solid #f3e4ea;
}

.btn-rosa {
    background: #B96880;
    color: white;
    border: none;
    border-radius: 7px;
    padding: 10px 17px;
}

.btn-rosa:hover {
    background: #a6536c;
    color: white;
}

.tabla-proveedores th {
    background: #f9edf1;
    color: #805466;
}

.tabla-proveedores td,
.tabla-proveedores th {
    padding: 12px;
    vertical-align: middle !important;
}

.form-control {
    border-radius: 7px;
}

.estado-activo {
    color: #27834c;
    font-weight: bold;
}

.estado-inactivo {
    color: #b96880;
    font-weight: bold;
}

.modal-proveedor {
    display: none;
    position: fixed;
    z-index: 9999;
    inset: 0;
    background: rgba(0,0,0,.45);
    align-items: center;
    justify-content: center;
    padding: 15px;
}

.modal-proveedor-contenido {
    background: white;
    width: 100%;
    max-width: 600px;
    border-radius: 12px;
    padding: 25px;
    box-shadow: 0 5px 25px rgba(0,0,0,.2);
}

.modal-proveedor-contenido h3 {
    color: #B96880;
    margin-top: 0;
    margin-bottom: 20px;
    font-weight: bold;
}

.campo-proveedor {
    margin-bottom: 15px;
}

.campo-proveedor label {
    color: #805466;
    margin-bottom: 6px;
}

.acciones-proveedor button {
    margin: 2px;
}

</style>

<div class="content-wrapper">

    <section class="content-header">
        <div class="proveedor-container proveedor-titulo">
            <h1><i class="fa fa-truck"></i> Gestión de Proveedores</h1>
            <p>Administra los proveedores de tu negocio.</p>
        </div>
    </section>

    <section class="content proveedor-container">

        <div class="proveedor-card">

            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
                <h4 style="color:#805466;font-weight:bold;margin:0;">
                    Lista de proveedores
                </h4>

                <button class="btn-rosa" onclick="abrirNuevo()">
                    <i class="fa fa-plus"></i> Nuevo proveedor
                </button>
            </div>

            <div id="mensajeProveedor"></div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover tabla-proveedores">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Documento</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Dirección</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>

                    <tbody id="tablaProveedores">
                        <tr>
                            <td colspan="8" class="text-center">
                                Cargando proveedores...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>

    </section>

</div>

<!-- MODAL -->
<div class="modal-proveedor" id="modalProveedor">

    <div class="modal-proveedor-contenido">

        <h3 id="tituloModal">Nuevo proveedor</h3>

        <form id="formProveedor">

            <input type="hidden" id="idProveedor" name="id">

            <div class="campo-proveedor">
                <label>Nombre del proveedor *</label>
                <input type="text" class="form-control" name="nombre" id="nombre" required maxlength="150">
            </div>

            <div class="row">
                <div class="col-md-6 campo-proveedor">
                    <label>DNI / RUC</label>
                    <input type="text" class="form-control" name="documento" id="documento" maxlength="20">
                </div>

                <div class="col-md-6 campo-proveedor">
                    <label>Teléfono</label>
                    <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20">
                </div>
            </div>

            <div class="campo-proveedor">
                <label>Correo electrónico</label>
                <input type="email" class="form-control" name="correo" id="correo" maxlength="100">
            </div>

            <div class="campo-proveedor">
                <label>Dirección</label>
                <input type="text" class="form-control" name="direccion" id="direccion" maxlength="255">
            </div>

            <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;">
                <button type="button" class="btn btn-default" onclick="cerrarModal()">
                    Cancelar
                </button>

                <button type="submit" class="btn-rosa">
                    <i class="fa fa-save"></i> Guardar proveedor
                </button>
            </div>

        </form>

    </div>

</div>

<script>
const URL_PROVEEDOR = "../ajax/proveedor.php";

const tablaProveedores = document.getElementById("tablaProveedores");
const modalProveedor = document.getElementById("modalProveedor");
const formProveedor = document.getElementById("formProveedor");
const mensajeProveedor = document.getElementById("mensajeProveedor");

function mostrarMensaje(mensaje, tipo = "success") {
    mensajeProveedor.innerHTML = "";

    const alerta = document.createElement("div");
    alerta.className = "alert alert-" + tipo;
    alerta.textContent = mensaje;

    mensajeProveedor.appendChild(alerta);

    setTimeout(() => {
        alerta.remove();
    }, 4000);
}

async function cargarProveedores() {
    try {
        const respuesta = await fetch(URL_PROVEEDOR + "?accion=listar");
        const resultado = await respuesta.json();

        if (!resultado.success) {
            throw new Error(resultado.mensaje || "No se pudieron cargar los proveedores.");
        }

        tablaProveedores.innerHTML = "";

        if (!resultado.data || resultado.data.length === 0) {
            tablaProveedores.innerHTML = `
                <tr>
                    <td colspan="8" class="text-center">
                        No hay proveedores registrados.
                    </td>
                </tr>`;
            return;
        }

        resultado.data.forEach(proveedor => {

            const fila = document.createElement("tr");

            const valores = [
                proveedor.id,
                proveedor.nombre,
                proveedor.documento || "-",
                proveedor.telefono || "-",
                proveedor.correo || "-",
                proveedor.direccion || "-"
            ];

            valores.forEach(valor => {
                const celda = document.createElement("td");
                celda.textContent = valor;
                fila.appendChild(celda);
            });

            const celdaEstado = document.createElement("td");
            const estado = document.createElement("span");

            estado.className = proveedor.estado === "Activo"
                ? "estado-activo"
                : "estado-inactivo";

            estado.textContent = proveedor.estado;
            celdaEstado.appendChild(estado);
            fila.appendChild(celdaEstado);

            const acciones = document.createElement("td");
            acciones.className = "acciones-proveedor";

            const editar = document.createElement("button");
            editar.className = "btn btn-warning btn-sm";
            editar.innerHTML = '<i class="fa fa-pencil"></i>';
            editar.title = "Editar proveedor";
            editar.onclick = () => editarProveedor(proveedor);

            const estadoBtn = document.createElement("button");
            estadoBtn.className = proveedor.estado === "Activo"
                ? "btn btn-danger btn-sm"
                : "btn btn-success btn-sm";

            estadoBtn.innerHTML = proveedor.estado === "Activo"
                ? '<i class="fa fa-ban"></i>'
                : '<i class="fa fa-check"></i>';

            estadoBtn.title = proveedor.estado === "Activo"
                ? "Desactivar"
                : "Activar";

            estadoBtn.onclick = () => cambiarEstado(
                proveedor.id,
                proveedor.estado === "Activo" ? "Inactivo" : "Activo"
            );

            acciones.appendChild(editar);
            acciones.appendChild(estadoBtn);
            fila.appendChild(acciones);

            tablaProveedores.appendChild(fila);
        });

    } catch (error) {
        tablaProveedores.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-danger">
                    ${error.message}
                </td>
            </tr>`;
    }
}

function abrirNuevo() {
    formProveedor.reset();
    document.getElementById("idProveedor").value = "";
    document.getElementById("tituloModal").textContent = "Nuevo proveedor";
    modalProveedor.style.display = "flex";
}

function editarProveedor(proveedor) {
    document.getElementById("idProveedor").value = proveedor.id;
    document.getElementById("nombre").value = proveedor.nombre;
    document.getElementById("documento").value = proveedor.documento || "";
    document.getElementById("telefono").value = proveedor.telefono || "";
    document.getElementById("correo").value = proveedor.correo || "";
    document.getElementById("direccion").value = proveedor.direccion || "";

    document.getElementById("tituloModal").textContent = "Editar proveedor";
    modalProveedor.style.display = "flex";
}

function cerrarModal() {
    modalProveedor.style.display = "none";
}

formProveedor.addEventListener("submit", async function(e) {
    e.preventDefault();

    const datos = new FormData(formProveedor);
    const id = document.getElementById("idProveedor").value;

    datos.append("accion", id ? "editar" : "agregar");

    try {
        const respuesta = await fetch(URL_PROVEEDOR, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo guardar.");
        }

        cerrarModal();
        mostrarMensaje(resultado.mensaje);
        cargarProveedores();

    } catch (error) {
        mostrarMensaje(error.message, "danger");
    }
});

async function cambiarEstado(id, estado) {
    if (!confirm("¿Deseas cambiar el estado de este proveedor?")) {
        return;
    }

    const datos = new FormData();
    datos.append("accion", "cambiarEstado");
    datos.append("id", id);
    datos.append("estado", estado);

    try {
        const respuesta = await fetch(URL_PROVEEDOR, {
            method: "POST",
            body: datos
        });

        const resultado = await respuesta.json();

        if (!resultado.success) {
            throw new Error(resultado.mensaje || "No se pudo cambiar el estado.");
        }

        mostrarMensaje(resultado.mensaje);
        cargarProveedores();

    } catch (error) {
        mostrarMensaje(error.message, "danger");
    }
}

cargarProveedores();
</script>

<?php
require_once __DIR__ . "/../footer.php";
?>
