
<?php
require_once 'header.php';
?>

<style>
.acerca-container {
    padding: 25px;
}

.acerca-card {
    background: white;
    border-radius: 16px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 4px 18px rgba(120,50,80,.09);
    max-width: 900px;
    margin: 20px auto;
}

.acerca-icono {
    width: 100px;
    height: 100px;
    margin: 0 auto 20px;
    border-radius: 50%;
    background: #F8E5EC;
    color: #B96880;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 45px;
}

.acerca-card h1 {
    color: #B96880;
    font-size: 32px;
    font-weight: bold;
    margin-bottom: 8px;
}

.acerca-card h3 {
    color: #A65370;
    font-size: 19px;
    margin-bottom: 20px;
}

.acerca-card p {
    color: #715B64;
    font-size: 15px;
    line-height: 1.9;
}

.acerca-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-top: 30px;
}

.acerca-item {
    background: #FFF5F8;
    border-radius: 10px;
    padding: 18px;
}

.acerca-item i {
    color: #B96880;
    font-size: 25px;
    margin-bottom: 10px;
}

.acerca-item h4 {
    color: #A65370;
    font-weight: bold;
}

.acerca-item span {
    color: #92717D;
    font-size: 13px;
}

.acerca-footer {
    color: #B96880 !important;
    font-weight: bold;
    margin-top: 30px;
}
</style>

<div class="content-wrapper">

    <section class="content-header acerca-container">

        <div class="acerca-card">

            <div class="acerca-icono">
                <i class="fa fa-shopping-bag"></i>
            </div>

            <h1>VENTAS MERCEDES</h1>

            <h3>Sistema de Gestión Comercial</h3>

            <p>
                VENTAS MERCEDES es un sistema de gestión desarrollado
                para facilitar la administración y el control de un negocio
                dedicado a la comercialización de prendas de vestir.
            </p>

            <p>
                Su finalidad es organizar la información de los productos,
                controlar el inventario, registrar compras y ventas,
                administrar clientes y proveedores, y facilitar las
                consultas de las operaciones realizadas.
            </p>

            <div class="acerca-info">

                <div class="acerca-item">
                    <i class="fa fa-cubes"></i>
                    <h4>Inventario</h4>
                    <span>Control de productos, tallas y colores.</span>
                </div>

                <div class="acerca-item">
                    <i class="fa fa-shopping-cart"></i>
                    <h4>Compras</h4>
                    <span>Registro de proveedores y compras.</span>
                </div>

                <div class="acerca-item">
                    <i class="fa fa-shopping-bag"></i>
                    <h4>Ventas</h4>
                    <span>Registro y control de ventas.</span>
                </div>

                <div class="acerca-item">
                    <i class="fa fa-users"></i>
                    <h4>Administración</h4>
                    <span>Gestión de clientes y usuarios.</span>
                </div>

            </div>

            <p class="acerca-footer">
                © <?php echo date('Y'); ?> VENTAS MERCEDES
                <br>
                Sistema de Gestión Comercial
            </p>

        </div>

    </section>

</div>

<?php require_once 'footer.php'; ?>
