
<?php
session_start();

if (isset($_SESSION['logueado']) && $_SESSION['logueado'] === true) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión | Ventas Mercedes</title>

    <link rel="stylesheet" href="../public/css/bootstrap.min.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #f8dce6, #f5c3d4, #e9a9c0);
            font-family: Arial, sans-serif;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
            padding: 20px;
        }

        .login-card {
            background: white;
            padding: 38px 32px;
            border-radius: 18px;
            box-shadow: 0 10px 35px rgba(120, 50, 80, 0.18);
        }

        .login-logo {
            text-align: center;
            margin-bottom: 25px;
        }

        .login-logo h1 {
            color: #b96880;
            font-size: 29px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .login-logo p {
            color: #92717d;
            margin: 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            color: #754b5c;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-control {
            height: 45px;
            border-radius: 9px;
            border: 1px solid #e8c4d1;
            box-shadow: none;
        }

        .form-control:focus {
            border-color: #bd718b;
            box-shadow: 0 0 0 3px rgba(189, 113, 139, 0.12);
        }

        .btn-login {
            width: 100%;
            height: 46px;
            border: none;
            border-radius: 9px;
            background: #b96880;
            color: white;
            font-weight: bold;
            font-size: 16px;
            transition: .2s;
        }

        .btn-login:hover {
            background: #a65370;
            color: white;
        }

        .mensaje {
            display: none;
            padding: 11px;
            border-radius: 8px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .mensaje.error {
            display: block;
            background: #fce4e4;
            color: #a52a2a;
        }

        .login-footer {
            text-align: center;
            margin-top: 25px;
            color: #a18490;
            font-size: 12px;
        }
    </style>
</head>

<body>

    <div class="login-container">

        <div class="login-card">

            <div class="login-logo">
                <h1>VENTAS MERCEDES</h1>
                <p>Sistema de Gestión Comercial</p>
            </div>

            <div id="mensaje" class="mensaje"></div>

            <form id="formLogin">

                <div class="form-group">
                    <label for="usuario">Usuario</label>
                    <input
                        type="text"
                        id="usuario"
                        name="usuario"
                        class="form-control"
                        placeholder="Ingresa tu usuario"
                        autocomplete="username"
                        required>
                </div>

                <div class="form-group">
                    <label for="clave">Contraseña</label>
                    <input
                        type="password"
                        id="clave"
                        name="clave"
                        class="form-control"
                        placeholder="Ingresa tu contraseña"
                        autocomplete="current-password"
                        required>
                </div>

                <button type="submit" class="btn-login" id="btnLogin">
                    Iniciar sesión
                </button>

            </form>

            <div class="login-footer">
                © <?php echo date('Y'); ?> Ventas Mercedes
                <br>
                Sistema de Gestión
            </div>

        </div>

    </div>

    <script>
        const formLogin = document.getElementById('formLogin');
        const mensaje = document.getElementById('mensaje');
        const btnLogin = document.getElementById('btnLogin');

        formLogin.addEventListener('submit', async function(e) {

            e.preventDefault();

            mensaje.className = 'mensaje';
            mensaje.textContent = '';

            btnLogin.disabled = true;
            btnLogin.textContent = 'Verificando...';

            const datos = new FormData(formLogin);
            datos.append('accion', 'login');

            try {

                const respuesta = await fetch('../ajax/acceso.php', {
                    method: 'POST',
                    body: datos
                });

                const resultado = await respuesta.json();

                if (resultado.ok) {
                    window.location.href = 'dashboard.php';
                } else {
                    mensaje.textContent = resultado.mensaje;
                    mensaje.className = 'mensaje error';
                }

            } catch (error) {

                mensaje.textContent = 'No se pudo conectar con el servidor.';
                mensaje.className = 'mensaje error';

            } finally {

                btnLogin.disabled = false;
                btnLogin.textContent = 'Iniciar sesión';

            }

        });
    </script>

</body>
</html>
