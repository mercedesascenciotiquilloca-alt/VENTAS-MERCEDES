
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ventas Mercedes | Sistema de Gestión</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <base href="/sistema%20MVC/vistas/">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="../public/css/bootstrap.min.css">

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="../public/css/font-awesome.css">

    <!-- ADMINLTE -->
    <link rel="stylesheet" href="../public/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../public/css/_all-skins.min.css">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="../public/datatables/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../public/datatables/buttons.dataTables.min.css">
    <link rel="stylesheet" href="../public/datatables/responsive.dataTables.min.css">

    <!-- SELECT -->
    <link rel="stylesheet" href="../public/css/bootstrap-select.min.css">

    <link rel="shortcut icon" href="../public/img/favicon.ico">

    <style>
        :root {
            --rosa: #D94F91;
            --rosa-fuerte: #BC3478;
            --rosa-claro: #FCE8F1;
            --rosa-suave: #FFF5F9;
            --malva: #80516D;
            --texto: #493442;
            --gris: #8B7883;
            --blanco: #FFFFFF;
            --borde: #F1DCE7;
            --sombra: 0 5px 20px rgba(173, 83, 127, .09);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif !important;
            background: var(--rosa-suave) !important;
            color: var(--texto);
        }

        /* ENCABEZADO SUPERIOR */

        .main-header {
            max-height: 55px;
        }

        .main-header .logo {
            background: linear-gradient(135deg, #F5B6D1, #E98DB9) !important;
            color: #752D55 !important;
            font-size: 19px;
            font-weight: 800;
            letter-spacing: .5px;
            border-bottom: 1px solid #F4D1E1;
        }

        .main-header .logo:hover {
            background: #E98DB9 !important;
        }

        .main-header .navbar {
            background: #FFFFFF !important;
            box-shadow: 0 2px 12px rgba(100, 50, 75, .06);
        }

        .main-header .navbar .sidebar-toggle {
            color: var(--rosa-fuerte) !important;
        }

        .main-header .navbar .sidebar-toggle:hover {
            background: var(--rosa-claro) !important;
        }

        .main-header .navbar-custom-menu > .navbar-nav > li > a {
            color: var(--malva) !important;
        }

        .main-header .navbar-custom-menu > .navbar-nav > li > a:hover {
            background: var(--rosa-claro) !important;
        }

        .main-header .user-image {
            border: 2px solid #F3B4D0;
        }

        .main-header .navbar .dropdown-menu {
            border: 1px solid var(--borde);
            border-radius: 12px;
            box-shadow: var(--sombra);
            overflow: hidden;
        }

        .user-header {
            background: linear-gradient(135deg, #F9C6DC, #E98DB9) !important;
        }

        .user-header p {
            color: #6C294C !important;
        }

        .user-footer {
            background: #FFF8FB !important;
        }

        /* MENU LATERAL */

        .main-sidebar {
            background: #FFF5F9 !important;
            box-shadow: 3px 0 15px rgba(120, 50, 85, .06);
        }

        .sidebar {
            background: #FFF5F9 !important;
        }

        .user-panel {
            border-bottom: 1px solid var(--borde) !important;
        }

        .sidebar-menu {
            padding-top: 12px;
        }

        .sidebar-menu > li.header {
            background: transparent !important;
            color: #B27A96 !important;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.5px;
            padding: 18px 20px 10px;
        }

        .sidebar-menu > li {
            margin: 4px 10px;
        }

        .sidebar-menu > li > a {
            color: #67475A !important;
            padding: 13px 15px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 10px;
            border-left: 3px solid transparent;
            transition: all .2s ease;
        }

        .sidebar-menu > li > a > .fa {
            width: 25px;
            font-size: 17px;
            color: #C45C8D;
        }

        .sidebar-menu > li > a:hover {
            background: #F9DCE9 !important;
            color: #A72D68 !important;
            border-left: 3px solid var(--rosa);
            transform: translateX(2px);
        }

        .sidebar-menu > li.active > a,
        .sidebar-menu > li.menu-open > a {
            background: linear-gradient(135deg, #E88BB6, #CB4F8D) !important;
            color: white !important;
            border-left: 3px solid #A72D68;
            box-shadow: 0 4px 10px rgba(203, 79, 141, .18);
        }

        .sidebar-menu > li.active > a > .fa,
        .sidebar-menu > li.menu-open > a > .fa {
            color: white !important;
        }

        /* SUBMENUS */

        .treeview-menu {
            background: #FCEBF2 !important;
            border-radius: 0 0 10px 10px;
            margin-top: 3px;
            padding: 5px 0;
        }

        .treeview-menu > li > a {
            color: #80516D !important;
            padding: 11px 12px 11px 35px;
            font-size: 13px;
        }

        .treeview-menu > li > a > .fa {
            color: #D77BA5;
            font-size: 11px;
        }

        .treeview-menu > li > a:hover,
        .treeview-menu > li.active > a {
            color: #B42F70 !important;
            background: #F8D6E5 !important;
            border-radius: 7px;
        }

        /* CONTENIDO */

        .content-wrapper {
            background: #FFF8FB !important;
        }

        .content {
            padding: 20px 25px;
        }

        .content-header {
            padding: 20px 25px 5px;
        }

        .content-header h1 {
            color: #A84276 !important;
            font-size: 25px;
            font-weight: 700;
        }

        .content-header small {
            color: #A58A99;
        }

        /* PANELES */

        .box {
            background: #FFFFFF !important;
            border-top: 3px solid #E78DB5 !important;
            border-radius: 13px !important;
            box-shadow: var(--sombra);
            margin-bottom: 22px;
            overflow: hidden;
        }

        .box-header {
            color: #87516E !important;
            padding: 16px 18px;
            border-bottom: 1px solid #F8E8EF;
        }

        .box-title {
            color: #A84276 !important;
            font-weight: 700 !important;
        }

        .box-body {
            padding: 18px;
        }

        .box-footer {
            background: #FFF9FC !important;
            border-top: 1px solid var(--borde);
        }

        /* BOTONES */

        .btn {
            border-radius: 8px !important;
            font-weight: 600;
            transition: all .2s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #E98DB9, #CA4E8D) !important;
            border-color: #D66B9E !important;
            color: white !important;
        }

        .btn-primary:hover {
            background: #B93678 !important;
            transform: translateY(-1px);
        }

        .btn-success {
            background: #63B99A !important;
            border-color: #63B99A !important;
        }

        .btn-danger {
            background: #DF6B7D !important;
            border-color: #DF6B7D !important;
        }

        .btn-warning {
            background: #E8B65F !important;
            border-color: #E8B65F !important;
        }

        .btn-default {
            border-color: #EBD9E2 !important;
            color: #80516D !important;
        }

        /* TABLAS */

        .table {
            background: #FFFFFF;
            border-radius: 9px;
        }

        .table > thead > tr > th {
            background: #F9E2EC !important;
            color: #874667 !important;
            border-bottom: 2px solid #EBC5D8 !important;
            padding: 12px 10px;
            font-weight: 700;
        }

        .table > tbody > tr > td {
            color: #674F5D;
            padding: 11px 10px;
            vertical-align: middle;
            border-top: 1px solid #F6EAF0;
        }

        .table > tbody > tr:hover {
            background: #FFF5F9 !important;
        }

        /* FORMULARIOS */

        .form-control,
        select.form-control {
            height: 38px;
            border-radius: 8px !important;
            border: 1px solid #EBD5E0 !important;
            box-shadow: none !important;
            color: #604657;
        }

        .form-control:focus {
            border-color: #DE82AC !important;
            box-shadow: 0 0 0 3px rgba(222, 130, 172, .12) !important;
        }

        label {
            color: #80516D;
            font-weight: 600;
        }

        .input-group-addon {
            background: #FCEBF2 !important;
            color: #B94F82;
            border-color: #EBD5E0 !important;
        }

        /* SELECT */

        .bootstrap-select > .dropdown-toggle {
            border-radius: 8px !important;
            border-color: #EBD5E0 !important;
        }

        /* ALERTAS */

        .alert {
            border-radius: 10px;
            border: none;
            box-shadow: var(--sombra);
        }

        /* DATA TABLES */

        .dataTables_wrapper {
            color: #684C5B;
        }

        .dataTables_wrapper .dataTables_filter input,
        .dataTables_wrapper .dataTables_length select {
            border: 1px solid #EBD5E0;
            border-radius: 7px;
            padding: 6px;
            background: white;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #E98DB9 !important;
            border-color: #E98DB9 !important;
            color: white !important;
            border-radius: 6px;
        }

        /* PIE DE PAGINA */

        .main-footer {
            background: #FFFFFF !important;
            border-top: 1px solid #F0DCE5 !important;
            color: #886A7B;
            padding: 15px 20px;
        }

        /* TARJETAS ADMINLTE */

        .small-box {
            border-radius: 13px !important;
            overflow: hidden;
            box-shadow: var(--sombra);
        }

        .small-box .icon {
            color: rgba(255,255,255,.25) !important;
        }

        /* PERFIL DE MERCEDES DEBAJO DEL LOGO VENTAS MERCEDES */

        .sidebar-menu > li.perfil-ropa-contenedor {
            margin: 8px 12px 16px;
            padding: 0;
            border: none;
        }

        .perfil-ropa {
            padding: 15px 10px;
            text-align: center;
            background: linear-gradient(135deg, #FCE8F1, #F8D5E4);
            border: 1px solid #F0C5D8;
            border-radius: 13px;
            box-shadow: 0 4px 12px rgba(173, 83, 127, .08);
        }

        .perfil-ropa .foto-perfil {
            display: block;
            width: 76px;
            height: 76px;
            margin: 0 auto 9px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #D94F91;
            padding: 2px;
            background: #FFFFFF;
        }

        .perfil-ropa h4 {
            margin: 7px 0 4px;
            color: #A84276;
            font-size: 15px;
            font-weight: 800;
        }

        .perfil-ropa p {
            margin: 0 0 9px;
            color: #80516D;
            font-size: 12px;
            line-height: 1.5;
        }

        .perfil-ropa .perfil-etiqueta {
            display: inline-block;
            padding: 5px 12px;
            color: #FFFFFF;
            background: #D94F91;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .perfil-ropa .perfil-etiqueta .fa {
            margin-right: 4px;
        }

        /* RESPONSIVE */

        @media (max-width: 767px) {
            .content {
                padding: 12px;
            }

            .content-header {
                padding: 15px 12px 5px;
            }

            .content-header h1 {
                font-size: 21px;
            }
        }
    </style>
</head>

<body class="hold-transition skin-blue-light sidebar-mini">

<div class="wrapper">

    <!-- ENCABEZADO -->
    <header class="main-header">

        <a href="dashboard.php" class="logo">
            <span class="logo-mini"><b>VM</b></span>
            <span class="logo-lg"><b>VENTAS</b> MERCEDES</span>
        </a>

        <nav class="navbar navbar-static-top">

            <a href="#" class="sidebar-toggle" data-toggle="offcanvas">
                <span class="sr-only">Navegación</span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">

                    <li class="dropdown user user-menu">

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="../public/dist/img/perfil-ventas.png"
                                 class="user-image" alt="Perfil">
                            <span class="hidden-xs">Mercedes</span>
                        </a>

                        <ul class="dropdown-menu">

                            <li class="user-header">
                                <img src="../public/dist/img/perfil-ventas.png"
                                     class="img-circle" alt="Perfil">

                                <p>
                                    Mercedes
                                    <small>Administradora de Ventas</small>
                                    <small>Sistema Ventas Mercedes</small>
                                </p>
                            </li>

                            <li class="user-footer">

                                <div class="pull-left">
                                    <a href="acceso/usuario.php"
                                       class="btn btn-default btn-flat">
                                        <i class="fa fa-user"></i> Perfil
                                    </a>
                                </div>

                                <div class="pull-right">
                                    <a href="../index.php"
                                       class="btn btn-default btn-flat">
                                        <i class="fa fa-sign-out"></i> Salir
                                    </a>
                                </div>

                            </li>

                        </ul>
                    </li>

                </ul>
            </div>

        </nav>
    </header>

    <!-- MENU LATERAL -->
    <aside class="main-sidebar">
        <section class="sidebar">

            <ul class="sidebar-menu">

                <!-- PERFIL DE MERCEDES: DEBAJO DEL LOGO VENTAS MERCEDES -->
                <li class="perfil-ropa-contenedor">
                    <div class="perfil-ropa">
                        <img src="../public/dist/img/perfil-ventas.png"
                             class="foto-perfil"
                             alt="Fotografía de Mercedes">
                        <h4>Mercedes</h4>
                        <p>Ventas de ropa y accesorios</p>
                        <span class="perfil-etiqueta">
                            <i class="fa fa-shopping-bag"></i> Vendedora
                        </span>
                    </div>
                </li>

                <li class="header">MENÚ PRINCIPAL</li>

                <li>
                    <a href="dashboard.php">
                        <i class="fa fa-home"></i>
                        <span>Escritorio</span>
                    </a>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-cubes"></i>
                        <span>Almacén</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu">
                        <li>
                            <a href="listado.php">
                                <i class="fa fa-circle-o"></i> Artículos
                            </a>
                        </li>

                        <li>
                            <a href="categoria/index.php">
                                <i class="fa fa-circle-o"></i> Categorías
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-shopping-bag"></i>
                        <span>Compras</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu">
                        <li>
                            <a href="compras/ingreso.php">
                                <i class="fa fa-circle-o"></i> Ingresos
                            </a>
                        </li>

                        <li>
                            <a href="compras/proveedor.php">
                                <i class="fa fa-circle-o"></i> Proveedores
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-shopping-cart"></i>
                        <span>Ventas</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu">
                        <li>
                            <a href="ventas/venta.php">
                                <i class="fa fa-circle-o"></i> Ventas
                            </a>
                        </li>

                        <li>
                            <a href="ventas/cliente.php">
                                <i class="fa fa-circle-o"></i> Clientes
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-users"></i>
                        <span>Acceso</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu">
                        <li>
                            <a href="acceso/usuario.php">
                                <i class="fa fa-circle-o"></i> Usuarios
                            </a>
                        </li>

                        <li>
                            <a href="acceso/permiso.php">
                                <i class="fa fa-circle-o"></i> Permisos
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-bar-chart"></i>
                        <span>Consulta Compras</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu">
                        <li>
                            <a href="consultas/consultacompras.php">
                                <i class="fa fa-circle-o"></i> Consulta Compras
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-line-chart"></i>
                        <span>Consulta Ventas</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu">
                        <li>
                            <a href="consultas/consultaventas.php">
                                <i class="fa fa-circle-o"></i> Consulta Ventas
                            </a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="ayuda.php">
                        <i class="fa fa-question-circle"></i>
                        <span>Ayuda</span>
                    </a>
                </li>

                <li>
                    <a href="acercade.php">
                        <i class="fa fa-info-circle"></i>
                        <span>Acerca de...</span>
                    </a>
                </li>

            </ul>
        </section>
    </aside>

    <!-- EL CONTENIDO DE CADA VISTA CONTINÚA AQUÍ -->
