
var tabla;

// Función que se ejecuta al inicio
function init() {
    mostrarform(false);
    listar();

    $("#formulario").on("submit", function(e) {
        guardaryeditar(e);
    });
}

// Limpiar formulario
function limpiar() {
    $("#nombre").val("");
    $("#descripcion").val("");
    $("#idmodulo").val("");
}

// Mostrar formulario
function mostrarform(flag) {
    limpiar();

    if (flag) {
        $("#listadoregistros").hide();
        $("#formularioregistros").show();
        $("#btnGuardar").prop("disabled", false);
        $("#btnagregar").hide();
    } else {
        $("#listadoregistros").show();
        $("#formularioregistros").hide();
        $("#btnagregar").show();
    }
}

// Cancelar formulario
function cancelarform() {
    limpiar();
    mostrarform(false);
}

// Listar módulos
function listar() {
    tabla = $('#tbllistado').dataTable({
        "aProcessing": true,
        "aServerSide": true,
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdf'
        ],
        "ajax": {
            url: '../ajax/modulo.php?op=listar',
            type: "get",
            dataType: "json",
            error: function(e) {
                console.log(e.responseText);
            }
        },
        "bDestroy": true,
        "iDisplayLength": 5,
        "order": [[0, "asc"]]
    }).DataTable();
}

// Guardar o editar módulo
function guardaryeditar(e) {
    e.preventDefault();

    $("#btnGuardar").prop("disabled", true);

    var formData = new FormData($("#formulario")[0]);

    $.ajax({
        url: "../ajax/modulo.php?op=guardaryeditar",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,

        success: function(datos) {
            bootbox.alert(datos);
            mostrarform(false);
            tabla.ajax.reload();
        },
        error: function(e) {
            console.log(e.responseText);
            $("#btnGuardar").prop("disabled", false);
        }
    });

    limpiar();
}

// Mostrar módulo
function mostrar(idmodulo) {
    $.post(
        "../ajax/modulo.php?op=mostrar",
        { idmodulo: idmodulo },
        function(data, status) {
            data = JSON.parse(data);

            mostrarform(true);

            $("#nombre").val(data.nombre);
            $("#descripcion").val(data.descripcion);
            $("#idmodulo").val(data.idmodulo);
            $("#estado").val(data.estado);
        }
    );
}

// Desactivar módulo
function desactivar(idmodulo) {
    bootbox.confirm("¿Está seguro de desactivar este módulo?", function(result) {
        if (result) {
            $.post(
                "../ajax/modulo.php?op=desactivar",
                { idmodulo: idmodulo },
                function(e) {
                    bootbox.alert(e);
                    tabla.ajax.reload();
                }
            );
        }
    });
}

// Activar módulo
function activar(idmodulo) {
    bootbox.confirm("¿Está seguro de activar este módulo?", function(result) {
        if (result) {
            $.post(
                "../ajax/modulo.php?op=activar",
                { idmodulo: idmodulo },
                function(e) {
                    bootbox.alert(e);
                    tabla.ajax.reload();
                }
            );
        }
    });
}

init();
