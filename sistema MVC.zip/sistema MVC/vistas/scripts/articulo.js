
$(document).ready(function () {
    listarArticulos();

    $("#formularioArticulo").on("submit", function (e) {
        e.preventDefault();
        guardarArticulo();
    });
});

// LISTAR ARTÍCULOS
function listarArticulos() {
    $.ajax({
        url: "../ajax/articulo.php",
        type: "GET",
        data: { accion: "listar" },
        dataType: "json",

        success: function (respuesta) {
            if (!respuesta.success) return;

            let filas = "";

            respuesta.data.forEach(function (a) {
                filas += `
                    <tr>
                        <td>${a.id}</td>
                        <td>${a.codigo}</td>
                        <td>${a.nombre}</td>
                        <td>${a.categoria}</td>
                        <td>S/ ${Number(a.precio).toFixed(2)}</td>
                        <td>${a.stock}</td>
                        <td>${a.estado}</td>
                        <td>
                            <button class="btn btn-warning btn-sm"
                                onclick="editarArticulo(${a.id})">
                                Editar
                            </button>
                            <button class="btn btn-danger btn-sm"
                                onclick="eliminarArticulo(${a.id})">
                                Eliminar
                            </button>
                        </td>
                    </tr>`;
            });

            $("#tablaArticulos tbody").html(filas);
        },

        error: function (xhr) {
            console.error(xhr.responseText);
            alert("Error al cargar los artículos.");
        }
    });
}

// GUARDAR O EDITAR
function guardarArticulo() {
    let formulario = $("#formularioArticulo")[0];
    let datos = new FormData(formulario);

    $.ajax({
        url: "../ajax/articulo.php",
        type: "POST",
        data: datos,
        contentType: false,
        processData: false,
        dataType: "json",

        success: function (respuesta) {
            alert(respuesta.mensaje);

            if (respuesta.success) {
                formulario.reset();
                $("#id").val("");
                $("#accion").val("agregar");
                listarArticulos();
            }
        },

        error: function (xhr) {
            console.error(xhr.responseText);
            alert("No se pudo guardar el artículo.");
        }
    });
}

// CARGAR ARTÍCULO PARA EDITAR
function editarArticulo(id) {
    $.get("../ajax/articulo.php", { accion: "listar" }, function (respuesta) {
        if (!respuesta.success) return;

        let articulo = respuesta.data.find(a => Number(a.id) === Number(id));

        if (!articulo) {
            alert("No se encontró el artículo.");
            return;
        }

        $("#id").val(articulo.id);
        $("#codigo").val(articulo.codigo);
        $("#nombre").val(articulo.nombre);
        $("#categoria").val(articulo.categoria_id);
        $("#precio").val(articulo.precio);
        $("#estado").val(articulo.estado);
        $("#accion").val("editar");

        if (typeof cargarVariantes === "function") {
            cargarVariantes(articulo.variantes);
        }

        if (typeof mostrarform === "function") {
            mostrarform(true);
        }
    }, "json");
}

// ELIMINAR ARTÍCULO
function eliminarArticulo(id) {
    if (!confirm("¿Estás segura de eliminar esta prenda?")) return;

    let datos = new FormData();
    datos.append("accion", "eliminar");
    datos.append("id", id);

    $.ajax({
        url: "../ajax/articulo.php",
        type: "POST",
        data: datos,
        contentType: false,
        processData: false,
        dataType: "json",

        success: function (respuesta) {
            alert(respuesta.mensaje);

            if (respuesta.success) {
                listarArticulos();
            }
        },

        error: function (xhr) {
            console.error(xhr.responseText);
            alert("No se pudo eliminar el artículo.");
        }
    });
}
