
<?php

require_once "Conexion.php";

$conexion = new Conexion();
$pdo = $conexion->conectar();

echo "<h2>¡CONEXIÓN EXITOSA!</h2>";
echo "VENTAS MERCEDES está conectado a MySQL.";
