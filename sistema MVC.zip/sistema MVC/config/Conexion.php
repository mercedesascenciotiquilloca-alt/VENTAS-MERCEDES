
<?php

class Conexion
{
    private $host = "localhost";
    private $bd = "sistema MVC";
    private $usuario = "root";
    private $password = "";

    public function conectar()
    {
        try {
            $conexion = new PDO(
                "mysql:host=" . $this->host .
                ";dbname=" . $this->bd .
                ";charset=utf8mb4",
                $this->usuario,
                $this->password
            );

            $conexion->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $conexion->setAttribute(
                PDO::ATTR_DEFAULT_FETCH_MODE,
                PDO::FETCH_ASSOC
            );

            return $conexion;

        } catch (PDOException $e) {
            error_log($e->getMessage());
            die("Error al conectar con la base de datos.");
        }
    }
}
