
<?php
require_once __DIR__ . "/../config/Conexion.php";

class Permiso
{
    private $conexion;

    public function __construct()
    {
        $con = new Conexion();
        $this->conexion = $con->conectar();
    }

    // Obtener usuarios y módulos
    public function obtenerDatos()
    {
        $usuarios = $this->conexion->query(
            "SELECT idusuario, nombre, usuario
             FROM usuarios
             WHERE estado = 'Activo'
             ORDER BY nombre"
        )->fetchAll(PDO::FETCH_ASSOC);

        $modulos = $this->conexion->query(
            "SELECT idmodulo, nombre, descripcion
             FROM modulos
             ORDER BY idmodulo"
        )->fetchAll(PDO::FETCH_ASSOC);

        return [
            "usuarios" => $usuarios,
            "modulos" => $modulos
        ];
    }

    // Listar permisos de un usuario
    public function listar($idusuario)
    {
        $sql = "SELECT
                    m.idmodulo,
                    m.nombre AS modulo,
                    COALESCE(p.leer, 0) AS leer,
                    COALESCE(p.escribir, 0) AS escribir,
                    COALESCE(p.actualizar, 0) AS actualizar,
                    COALESCE(p.eliminar, 0) AS eliminar
                FROM modulos m
                LEFT JOIN permisos p
                    ON p.idmodulo = m.idmodulo
                    AND p.idusuario = ?
                ORDER BY m.idmodulo";

        $consulta = $this->conexion->prepare($sql);
        $consulta->execute([(int)$idusuario]);

        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    // Guardar permisos de un usuario
    public function guardar($idusuario, $permisos)
    {
        try {
            $idusuario = (int)$idusuario;

            if ($idusuario <= 0 || !is_array($permisos)) {
                throw new Exception("Datos de permisos incorrectos.");
            }

            $consultaUsuario = $this->conexion->prepare(
                "SELECT idusuario FROM usuarios
                 WHERE idusuario = ? AND estado = 'Activo'"
            );
            $consultaUsuario->execute([$idusuario]);

            if (!$consultaUsuario->fetch()) {
                throw new Exception("El usuario no existe o está inactivo.");
            }

            $this->conexion->beginTransaction();

            $sql = "INSERT INTO permisos
                    (idusuario, idmodulo, leer, escribir, actualizar, eliminar)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        leer = VALUES(leer),
                        escribir = VALUES(escribir),
                        actualizar = VALUES(actualizar),
                        eliminar = VALUES(eliminar)";

            $guardar = $this->conexion->prepare($sql);

            $moduloValido = $this->conexion->prepare(
                "SELECT idmodulo FROM modulos WHERE idmodulo = ?"
            );

            foreach ($permisos as $p) {
                $idmodulo = (int)($p["idmodulo"] ?? 0);

                if ($idmodulo <= 0) {
                    throw new Exception("Se encontró un módulo inválido.");
                }

                $moduloValido->execute([$idmodulo]);

                if (!$moduloValido->fetch()) {
                    throw new Exception("Uno de los módulos no existe.");
                }

                $leer = !empty($p["leer"]) ? 1 : 0;
                $escribir = !empty($p["escribir"]) ? 1 : 0;
                $actualizar = !empty($p["actualizar"]) ? 1 : 0;
                $eliminar = !empty($p["eliminar"]) ? 1 : 0;

                $guardar->execute([
                    $idusuario,
                    $idmodulo,
                    $leer,
                    $escribir,
                    $actualizar,
                    $eliminar
                ]);
            }

            $this->conexion->commit();

            return [
                "ok" => true,
                "mensaje" => "Permisos guardados correctamente."
            ];

        } catch (Exception $e) {
            if ($this->conexion->inTransaction()) {
                $this->conexion->rollBack();
            }

            return [
                "ok" => false,
                "error" => $e->getMessage()
            ];
        }
    }
}
s