
<?php

require_once __DIR__ . '/../config/Conexion.php';

class Cliente
{
    private $conexion;

    public function __construct()
    {
        $con = new Conexion();
        $this->conexion = $con->conectar();
    }

    // LISTAR CLIENTES
    public function listar()
    {
        $sql = "SELECT * FROM clientes ORDER BY id DESC";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // AGREGAR CLIENTE
    public function agregar($datos)
    {
        $sql = "INSERT INTO clientes
                (nombre, documento, telefono, correo, direccion)
                VALUES
                (:nombre, :documento, :telefono, :correo, :direccion)";

        $stmt = $this->conexion->prepare($sql);

        return $stmt->execute([
            ':nombre' => trim($datos['nombre']),
            ':documento' => $this->valorNulo($datos['documento'] ?? ''),
            ':telefono' => $this->valorNulo($datos['telefono'] ?? ''),
            ':correo' => $this->valorNulo($datos['correo'] ?? ''),
            ':direccion' => $this->valorNulo($datos['direccion'] ?? '')
        ]);
    }

    // EDITAR CLIENTE
    public function editar($datos)
    {
        $sql = "UPDATE clientes SET
                    nombre = :nombre,
                    documento = :documento,
                    telefono = :telefono,
                    correo = :correo,
                    direccion = :direccion
                WHERE id = :id";

        $stmt = $this->conexion->prepare($sql);

        return $stmt->execute([
            ':nombre' => trim($datos['nombre']),
            ':documento' => $this->valorNulo($datos['documento'] ?? ''),
            ':telefono' => $this->valorNulo($datos['telefono'] ?? ''),
            ':correo' => $this->valorNulo($datos['correo'] ?? ''),
            ':direccion' => $this->valorNulo($datos['direccion'] ?? ''),
            ':id' => (int)$datos['id']
        ]);
    }

    // CAMBIAR ESTADO
    public function cambiarEstado($id, $estado)
    {
        if (!in_array($estado, ['Activo', 'Inactivo'], true)) {
            return false;
        }

        $sql = "UPDATE clientes SET estado = :estado WHERE id = :id";
        $stmt = $this->conexion->prepare($sql);

        return $stmt->execute([
            ':estado' => $estado,
            ':id' => (int)$id
        ]);
    }

    // CONVERTIR CAMPOS VACÍOS EN NULL
    private function valorNulo($valor)
    {
        $valor = trim((string)$valor);
        return $valor === '' ? null : $valor;
    }
}
