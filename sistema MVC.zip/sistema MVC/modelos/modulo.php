<?php

require_once __DIR__ . "/../config/Conexion.php";

class Modulos
{
    private $conexion;

    public function __construct()
    {
        $db = new Conexion();
        $this->conexion = $db->conectar();
    }

    public function insertar($nombre, $descripcion)
    {
        $sql = "INSERT INTO modulos (nombre, descripcion, estado)
                VALUES (:nombre, :descripcion, 1)";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion
        ]);
    }

    public function editar($idmodulo, $nombre, $descripcion, $estado)
    {
        $sql = "UPDATE modulos
                SET nombre = :nombre,
                    descripcion = :descripcion,
                    estado = :estado
                WHERE idmodulo = :idmodulo";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion,
            ":estado" => $estado,
            ":idmodulo" => $idmodulo
        ]);
    }

    public function desactivar($idmodulo)
    {
        $sql = "UPDATE modulos SET estado = 0
                WHERE idmodulo = :idmodulo";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":idmodulo" => $idmodulo
        ]);
    }

    public function activar($idmodulo)
    {
        $sql = "UPDATE modulos SET estado = 1
                WHERE idmodulo = :idmodulo";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":idmodulo" => $idmodulo
        ]);
    }

    public function mostrar($idmodulo)
    {
        $sql = "SELECT * FROM modulos
                WHERE idmodulo = :idmodulo";

        $consulta = $this->conexion->prepare($sql);

        $consulta->execute([
            ":idmodulo" => $idmodulo
        ]);

        return $consulta->fetch(PDO::FETCH_ASSOC);
    }

    public function listar()
    {
        $sql = "SELECT idmodulo, nombre, descripcion, estado
                FROM modulos
                ORDER BY nombre ASC";

        $consulta = $this->conexion->prepare($sql);
        $consulta->execute();

        return $consulta;
    }
}
