
<?php

require_once __DIR__ . '/../config/Conexion.php';

class Acceso
{
    private $conexion;

    public function __construct()
    {
        $con = new Conexion();
        $this->conexion = $con->conectar();
    }

    public function iniciarSesion($usuario, $clave)
    {
        $sql = "SELECT idusuario, nombre, usuario, clave, estado
                FROM usuarios
                WHERE usuario = :usuario
                LIMIT 1";

        $stmt = $this->conexion->prepare($sql);
        $stmt->execute(['usuario' => $usuario]);

        $datos = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$datos) {
            return [
                'ok' => false,
                'mensaje' => 'El usuario o la contraseña son incorrectos.'
            ];
        }

        if ($datos['estado'] !== 'Activo') {
            return [
                'ok' => false,
                'mensaje' => 'Este usuario se encuentra inactivo.'
            ];
        }

        if (!password_verify($clave, $datos['clave'])) {
            return [
                'ok' => false,
                'mensaje' => 'El usuario o la contraseña son incorrectos.'
            ];
        }

        return [
            'ok' => true,
            'usuario' => [
                'idusuario' => $datos['idusuario'],
                'nombre' => $datos['nombre'],
                'usuario' => $datos['usuario']
            ]
        ];
    }
}
