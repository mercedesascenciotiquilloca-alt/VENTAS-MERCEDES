
<?php
require_once __DIR__ . "/../config/Conexion.php";

class Proveedor
{
    private $conexion;

    public function __construct()
    {
        $db = new Conexion();
        $this->conexion = $db->conectar();
    }

    public function listar()
    {
        $sql = "SELECT * FROM proveedores ORDER BY id DESC";
        $consulta = $this->conexion->prepare($sql);
        $consulta->execute();

        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    public function agregar($datos)
    {
        $sql = "INSERT INTO proveedores
                (nombre, documento, telefono, correo, direccion, estado)
                VALUES
                (:nombre, :documento, :telefono, :correo, :direccion, 'Activo')";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":nombre" => $datos["nombre"],
            ":documento" => $datos["documento"] ?: null,
            ":telefono" => $datos["telefono"],
            ":correo" => $datos["correo"],
            ":direccion" => $datos["direccion"]
        ]);
    }

    public function editar($datos)
    {
        $sql = "UPDATE proveedores SET
                nombre = :nombre,
                documento = :documento,
                telefono = :telefono,
                correo = :correo,
                direccion = :direccion
                WHERE id = :id";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":id" => $datos["id"],
            ":nombre" => $datos["nombre"],
            ":documento" => $datos["documento"] ?: null,
            ":telefono" => $datos["telefono"],
            ":correo" => $datos["correo"],
            ":direccion" => $datos["direccion"]
        ]);
    }

    public function cambiarEstado($id, $estado)
    {
        $sql = "UPDATE proveedores SET estado = :estado WHERE id = :id";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":id" => $id,
            ":estado" => $estado
        ]);
    }
}
