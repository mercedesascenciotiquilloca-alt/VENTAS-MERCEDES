
<?php
require_once __DIR__ . "/../config/Conexion.php";

class Venta
{
    private $conexion;

    public function __construct()
    {
        $con = new Conexion();
        $this->conexion = $con->conectar();
    }

    // Obtener clientes y prendas disponibles
    public function obtenerDatos()
    {
        $sqlClientes = "SELECT id, nombre, documento
                        FROM clientes
                        WHERE estado = 'Activo'
                        ORDER BY nombre ASC";

        $clientes = $this->conexion->query($sqlClientes)->fetchAll(PDO::FETCH_ASSOC);

        $sqlVariantes = "SELECT
                            v.id,
                            a.nombre AS articulo,
                            a.codigo,
                            v.talla,
                            v.color,
                            v.stock,
                            a.precio
                         FROM variantes_articulo v
                         INNER JOIN articulos a ON a.id = v.articulo_id
                         WHERE a.estado = 'Activo'
                         AND v.stock > 0
                         ORDER BY a.nombre, v.talla, v.color";

        $variantes = $this->conexion->query($sqlVariantes)->fetchAll(PDO::FETCH_ASSOC);

        return [
            "clientes" => $clientes,
            "variantes" => $variantes
        ];
    }

    // Historial de ventas
    public function listar()
    {
        $sql = "SELECT
                    v.id,
                    v.cliente_id,
                    COALESCE(c.nombre, 'Venta sin cliente') AS cliente,
                    v.fecha_venta,
                    v.comprobante,
                    v.total,
                    v.estado,
                    (
                        SELECT COUNT(*)
                        FROM detalle_ventas d
                        WHERE d.venta_id = v.id
                    ) AS productos
                FROM ventas v
                LEFT JOIN clientes c ON c.id = v.cliente_id
                ORDER BY v.id DESC";

        return $this->conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Registrar venta y descontar stock
    public function registrar($clienteId, $comprobante, $detalles)
    {
        try {
            if (!is_array($detalles) || count($detalles) === 0) {
                throw new Exception("Agrega al menos un producto a la venta.");
            }

            $this->conexion->beginTransaction();

            // Validar cliente
            if ($clienteId !== null && $clienteId !== "") {
                $consultaCliente = $this->conexion->prepare(
                    "SELECT id FROM clientes
                     WHERE id = ? AND estado = 'Activo'"
                );
                $consultaCliente->execute([$clienteId]);

                if (!$consultaCliente->fetch()) {
                    throw new Exception("El cliente seleccionado no existe o está inactivo.");
                }
            } else {
                $clienteId = null;
            }

            $total = 0;
            $productosVenta = [];

            foreach ($detalles as $detalle) {
                $varianteId = (int)($detalle["variante_id"] ?? 0);
                $cantidad = (int)($detalle["cantidad"] ?? 0);

                if ($varianteId <= 0 || $cantidad <= 0) {
                    throw new Exception("Hay productos con datos incorrectos.");
                }

                // Bloquear variante para evitar vender stock simultáneamente
                $consulta = $this->conexion->prepare(
                    "SELECT
                        v.id,
                        v.stock,
                        a.precio,
                        a.nombre
                     FROM variantes_articulo v
                     INNER JOIN articulos a ON a.id = v.articulo_id
                     WHERE v.id = ?
                     AND a.estado = 'Activo'
                     FOR UPDATE"
                );

                $consulta->execute([$varianteId]);
                $producto = $consulta->fetch(PDO::FETCH_ASSOC);

                if (!$producto) {
                    throw new Exception("Uno de los productos seleccionados no está disponible.");
                }

                if ($cantidad > (int)$producto["stock"]) {
                    throw new Exception(
                        "Stock insuficiente para " . $producto["nombre"] .
                        ". Disponible: " . $producto["stock"]
                    );
                }

                $precio = (float)$producto["precio"];
                $subtotal = $precio * $cantidad;

                $total += $subtotal;

                $productosVenta[] = [
                    "variante_id" => $varianteId,
                    "cantidad" => $cantidad,
                    "precio" => $precio,
                    "subtotal" => $subtotal
                ];
            }

            // Registrar cabecera de venta
            $sqlVenta = "INSERT INTO ventas
                         (cliente_id, comprobante, total, estado)
                         VALUES (?, ?, ?, 'Registrada')";

            $insertarVenta = $this->conexion->prepare($sqlVenta);
            $insertarVenta->execute([
                $clienteId,
                $comprobante ?: null,
                $total
            ]);

            $ventaId = $this->conexion->lastInsertId();

            // Registrar detalles y descontar stock
            $insertarDetalle = $this->conexion->prepare(
                "INSERT INTO detalle_ventas
                 (venta_id, variante_id, cantidad, precio_unitario, subtotal)
                 VALUES (?, ?, ?, ?, ?)"
            );

            $descontarStock = $this->conexion->prepare(
                "UPDATE variantes_articulo
                 SET stock = stock - ?
                 WHERE id = ? AND stock >= ?"
            );

            foreach ($productosVenta as $producto) {
                $insertarDetalle->execute([
                    $ventaId,
                    $producto["variante_id"],
                    $producto["cantidad"],
                    $producto["precio"],
                    $producto["subtotal"]
                ]);

                $descontarStock->execute([
                    $producto["cantidad"],
                    $producto["variante_id"],
                    $producto["cantidad"]
                ]);

                if ($descontarStock->rowCount() !== 1) {
                    throw new Exception("No se pudo actualizar el stock de uno de los productos.");
                }
            }

            $this->conexion->commit();

            return [
                "ok" => true,
                "mensaje" => "Venta registrada correctamente.",
                "venta_id" => $ventaId,
                "total" => $total
            ];

        } catch (Exception $e) {
            if ($this->conexion->inTransaction()) {
                $this->conexion->rollBack();
            }

            return [
                "ok" => false,
                "error" => $e->getMessage()
            ];
        }
    }
}
