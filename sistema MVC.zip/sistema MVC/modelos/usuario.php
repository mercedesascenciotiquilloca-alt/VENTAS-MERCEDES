
<?php
require_once __DIR__ . "/../config/Conexion.php";

class Usuario
{
    private $conexion;

    public function __construct()
    {
        $con = new Conexion();
        $this->conexion = $con->conectar();
    }

    public function listar()
    {
        $sql = "SELECT idusuario, nombre, usuario, correo, estado, fecha_creacion
                FROM usuarios
                ORDER BY idusuario DESC";

        return $this->conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function agregar($datos)
    {
        try {
            $sql = "INSERT INTO usuarios
                    (nombre, usuario, clave, correo, estado)
                    VALUES (?, ?, ?, ?, 'Activo')";

            $consulta = $this->conexion->prepare($sql);

            return $consulta->execute([
                trim($datos["nombre"]),
                trim($datos["usuario"]),
                password_hash($datos["clave"], PASSWORD_DEFAULT),
                !empty($datos["correo"]) ? trim($datos["correo"]) : null
            ]);

        } catch (PDOException $e) {
            return false;
        }
    }

    public function editar($datos)
    {
        try {
            $id = (int)$datos["id"];

            if (!empty($datos["clave"])) {
                $sql = "UPDATE usuarios
                        SET nombre = ?, usuario = ?, clave = ?, correo = ?
                        WHERE idusuario = ?";

                $consulta = $this->conexion->prepare($sql);

                return $consulta->execute([
                    trim($datos["nombre"]),
                    trim($datos["usuario"]),
                    password_hash($datos["clave"], PASSWORD_DEFAULT),
                    !empty($datos["correo"]) ? trim($datos["correo"]) : null,
                    $id
                ]);
            }

            $sql = "UPDATE usuarios
                    SET nombre = ?, usuario = ?, correo = ?
                    WHERE idusuario = ?";

            $consulta = $this->conexion->prepare($sql);

            return $consulta->execute([
                trim($datos["nombre"]),
                trim($datos["usuario"]),
                !empty($datos["correo"]) ? trim($datos["correo"]) : null,
                $id
            ]);

        } catch (PDOException $e) {
            return false;
        }
    }

    public function cambiarEstado($id, $estado)
    {
        if (!in_array($estado, ["Activo", "Inactivo"], true)) {
            return false;
        }

        $consulta = $this->conexion->prepare(
            "UPDATE usuarios SET estado = ? WHERE idusuario = ?"
        );

        return $consulta->execute([$estado, (int)$id]);
    }
}
