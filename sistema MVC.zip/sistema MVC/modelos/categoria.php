
<?php

require_once __DIR__ . "/../config/Conexion.php";

class Categoria
{
    private $conexion;

    public function __construct()
    {
        $db = new Conexion();
        $this->conexion = $db->conectar();
    }

    public function listar()
    {
        $sql = "SELECT id, nombre, descripcion, estado
                FROM categorias
                ORDER BY nombre ASC";

        $consulta = $this->conexion->prepare($sql);
        $consulta->execute();

        return $consulta->fetchAll();
    }

    public function agregar($nombre, $descripcion)
    {
        $sql = "INSERT INTO categorias
                (nombre, descripcion, estado)
                VALUES (:nombre, :descripcion, 'Activo')";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion
        ]);
    }

    public function editar($id, $nombre, $descripcion)
    {
        $sql = "UPDATE categorias
                SET nombre = :nombre,
                    descripcion = :descripcion
                WHERE id = :id";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":id" => $id,
            ":nombre" => $nombre,
            ":descripcion" => $descripcion
        ]);
    }

    public function cambiarEstado($id, $estado)
    {
        $sql = "UPDATE categorias
                SET estado = :estado
                WHERE id = :id";

        $consulta = $this->conexion->prepare($sql);

        return $consulta->execute([
            ":id" => $id,
            ":estado" => $estado
        ]);
    }
}
