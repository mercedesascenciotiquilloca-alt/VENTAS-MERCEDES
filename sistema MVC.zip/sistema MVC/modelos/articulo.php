
<?php

require_once __DIR__ . "/../config/Conexion.php";

class Articulo
{
    private $conexion;

    public function __construct()
    {
        $db = new Conexion();
        $this->conexion = $db->conectar();
    }

    private function obtenerCategoriaId($categoria)
    {
        if (is_numeric($categoria)) {
            $sql = "SELECT id FROM categorias WHERE id = ?";
            $consulta = $this->conexion->prepare($sql);
            $consulta->execute([(int)$categoria]);
        } else {
            $sql = "SELECT id FROM categorias WHERE nombre = ?";
            $consulta = $this->conexion->prepare($sql);
            $consulta->execute([trim($categoria)]);
        }

        $resultado = $consulta->fetch();

        if (!$resultado) {
            throw new Exception("La categoría seleccionada no existe.");
        }

        return $resultado["id"];
    }

    private function prepararVariantes($variantes)
    {
        if (!is_array($variantes)) {
            $variantes = [[
                "talla" => "Única",
                "color" => "Único",
                "stock" => (int)$variantes
            ]];
        }

        if (empty($variantes)) {
            throw new Exception("Debes registrar al menos una variante.");
        }

        $resultado = [];

        foreach ($variantes as $variante) {
            $talla = trim($variante["talla"] ?? "");
            $color = trim($variante["color"] ?? "");
            $stock = filter_var(
                $variante["stock"] ?? null,
                FILTER_VALIDATE_INT
            );

            if ($talla === "" || $color === "" ||
                $stock === false || $stock < 0) {
                throw new Exception("Revisa la talla, el color y el stock.");
            }

            $resultado[] = [
                "talla" => $talla,
                "color" => $color,
                "stock" => $stock
            ];
        }

        $combinaciones = [];

        foreach ($resultado as $variante) {
            $clave = mb_strtolower(
                $variante["talla"] . "|" . $variante["color"]
            );

            if (isset($combinaciones[$clave])) {
                throw new Exception("Hay tallas y colores repetidos.");
            }

            $combinaciones[$clave] = true;
        }

        return $resultado;
    }

    private function guardarVariantes($articuloId, $variantes)
    {
        $sql = "INSERT INTO variantes_articulo
                (articulo_id, talla, color, stock)
                VALUES (?, ?, ?, ?)";

        $consulta = $this->conexion->prepare($sql);

        foreach ($variantes as $variante) {
            $consulta->execute([
                $articuloId,
                $variante["talla"],
                $variante["color"],
                $variante["stock"]
            ]);
        }
    }

    // Obtener la fotografía actual de una prenda
    public function obtenerImagen($id)
    {
        $consulta = $this->conexion->prepare(
            "SELECT imagen FROM articulos WHERE id = ?"
        );
        $consulta->execute([(int)$id]);

        $resultado = $consulta->fetch();

        return $resultado["imagen"] ?? null;
    }

    // Listar artículos con variantes, stock e imagen
    public function listar()
    {
        $sql = "SELECT
                    a.id,
                    a.codigo,
                    a.nombre,
                    a.categoria_id,
                    c.nombre AS categoria,
                    a.precio,
                    a.estado,
                    a.fecha_registro,
                    a.imagen,
                    COALESCE(SUM(v.stock), 0) AS stock
                FROM articulos a
                INNER JOIN categorias c
                    ON a.categoria_id = c.id
                LEFT JOIN variantes_articulo v
                    ON a.id = v.articulo_id
                GROUP BY
                    a.id, a.codigo, a.nombre,
                    a.categoria_id, c.nombre,
                    a.precio, a.estado,
                    a.fecha_registro, a.imagen
                ORDER BY a.id DESC";

        $consulta = $this->conexion->prepare($sql);
        $consulta->execute();

        $articulos = $consulta->fetchAll();

        $sqlVariantes = "SELECT
                            id,
                            articulo_id,
                            talla,
                            color,
                            stock
                         FROM variantes_articulo
                         ORDER BY talla, color";

        $consultaVariantes = $this->conexion->prepare($sqlVariantes);
        $consultaVariantes->execute();

        $variantes = $consultaVariantes->fetchAll();

        $variantesPorArticulo = [];

        foreach ($variantes as $variante) {
            $variantesPorArticulo[$variante["articulo_id"]][] = $variante;
        }

        foreach ($articulos as &$articulo) {
            $articulo["variantes"] =
                $variantesPorArticulo[$articulo["id"]] ?? [];
        }

        unset($articulo);

        return $articulos;
    }

    // Agregar artículo
    public function agregar(
        $codigo,
        $nombre,
        $categoria,
        $precio,
        $variantes,
        $estado = "Activo",
        $imagen = null
    ) {
        try {
            $codigo = trim($codigo);
            $nombre = trim($nombre);
            $precio = filter_var($precio, FILTER_VALIDATE_FLOAT);

            if ($codigo === "" || $nombre === "" ||
                $precio === false || $precio < 0) {
                throw new Exception("Los datos del artículo no son válidos.");
            }

            if (!in_array($estado, ["Activo", "Inactivo"], true)) {
                throw new Exception("El estado no es válido.");
            }

            $categoriaId = $this->obtenerCategoriaId($categoria);
            $variantes = $this->prepararVariantes($variantes);

            $this->conexion->beginTransaction();

            $sql = "INSERT INTO articulos
                    (codigo, nombre, categoria_id, precio, estado, imagen)
                    VALUES (?, ?, ?, ?, ?, ?)";

            $consulta = $this->conexion->prepare($sql);

            $consulta->execute([
                $codigo,
                $nombre,
                $categoriaId,
                $precio,
                $estado,
                $imagen
            ]);

            $articuloId = $this->conexion->lastInsertId();

            $this->guardarVariantes($articuloId, $variantes);

            $this->conexion->commit();

            return true;

        } catch (Throwable $e) {
            if ($this->conexion->inTransaction()) {
                $this->conexion->rollBack();
            }

            error_log("Error al agregar artículo: " . $e->getMessage());
            return false;
        }
    }

    // Editar artículo y sus variantes
    public function editar(
        $id,
        $codigo,
        $nombre,
        $categoria,
        $precio,
        $variantes,
        $estado = "Activo",
        $imagen = null
    ) {
        try {
            $id = (int)$id;
            $codigo = trim($codigo);
            $nombre = trim($nombre);
            $precio = filter_var($precio, FILTER_VALIDATE_FLOAT);

            if ($id <= 0 || $codigo === "" || $nombre === "" ||
                $precio === false || $precio < 0) {
                throw new Exception("Los datos del artículo no son válidos.");
            }

            if (!in_array($estado, ["Activo", "Inactivo"], true)) {
                throw new Exception("El estado no es válido.");
            }

            $categoriaId = $this->obtenerCategoriaId($categoria);
            $variantes = $this->prepararVariantes($variantes);

            $this->conexion->beginTransaction();

            if ($imagen !== null) {
                $sql = "UPDATE articulos
                        SET codigo = ?,
                            nombre = ?,
                            categoria_id = ?,
                            precio = ?,
                            estado = ?,
                            imagen = ?
                        WHERE id = ?";

                $parametros = [
                    $codigo, $nombre, $categoriaId,
                    $precio, $estado, $imagen, $id
                ];
            } else {
                $sql = "UPDATE articulos
                        SET codigo = ?,
                            nombre = ?,
                            categoria_id = ?,
                            precio = ?,
                            estado = ?
                        WHERE id = ?";

                $parametros = [
                    $codigo, $nombre, $categoriaId,
                    $precio, $estado, $id
                ];
            }

            $consulta = $this->conexion->prepare($sql);
            $consulta->execute($parametros);

            $consultaExiste = $this->conexion->prepare(
                "SELECT id FROM articulos WHERE id = ?"
            );
            $consultaExiste->execute([$id]);

            if (!$consultaExiste->fetch()) {
                throw new Exception("El artículo no existe.");
            }

            $eliminar = $this->conexion->prepare(
                "DELETE FROM variantes_articulo WHERE articulo_id = ?"
            );
            $eliminar->execute([$id]);

            $this->guardarVariantes($id, $variantes);

            $this->conexion->commit();

            return true;

        } catch (Throwable $e) {
            if ($this->conexion->inTransaction()) {
                $this->conexion->rollBack();
            }

            error_log("Error al editar artículo: " . $e->getMessage());
            return false;
        }
    }

    // Eliminar artículo
    public function eliminar($id)
    {
        try {
            $sql = "DELETE FROM articulos WHERE id = ?";
            $consulta = $this->conexion->prepare($sql);
            $consulta->execute([(int)$id]);

            return $consulta->rowCount() > 0;

        } catch (PDOException $e) {
            error_log("Error al eliminar artículo: " . $e->getMessage());
            return false;
        }
    }
}
