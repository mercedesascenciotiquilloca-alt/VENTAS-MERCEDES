
<?php

require_once __DIR__ . '/../config/Conexion.php';

class Consulta
{
    private $conexion;

    public function __construct()
    {
        $con = new Conexion();
        $this->conexion = $con->conectar();
    }

    public function listarCompras()
    {
        $sql = "SELECT
                    c.id,
                    c.fecha_compra,
                    c.comprobante,
                    c.total,
                    c.estado,
                    p.nombre AS proveedor
                FROM compras c
                INNER JOIN proveedores p ON c.proveedor_id = p.id
                ORDER BY c.fecha_compra DESC, c.id DESC";

        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function detalleCompra($id)
    {
        $sql = "SELECT
                    a.nombre AS articulo,
                    va.talla,
                    va.color,
                    dc.cantidad,
                    dc.costo_unitario,
                    dc.subtotal
                FROM detalle_compras dc
                INNER JOIN variantes_articulo va
                    ON dc.variante_id = va.id
                INNER JOIN articulos a
                    ON va.articulo_id = a.id
                WHERE dc.compra_id = :id
                ORDER BY a.nombre, va.talla, va.color";

        $stmt = $this->conexion->prepare($sql);
        $stmt->execute(['id' => $id]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listarVentas()
    {
        $sql = "SELECT
                    v.id,
                    v.fecha_venta,
                    v.comprobante,
                    v.total,
                    v.estado,
                    COALESCE(c.nombre, 'Cliente general') AS cliente
                FROM ventas v
                LEFT JOIN clientes c ON v.cliente_id = c.id
                ORDER BY v.fecha_venta DESC, v.id DESC";

        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function detalleVenta($id)
    {
        $sql = "SELECT
                    a.nombre AS articulo,
                    va.talla,
                    va.color,
                    dv.cantidad,
                    dv.precio_unitario,
                    dv.subtotal
                FROM detalle_ventas dv
                INNER JOIN variantes_articulo va
                    ON dv.variante_id = va.id
                INNER JOIN articulos a
                    ON va.articulo_id = a.id
                WHERE dv.venta_id = :id
                ORDER BY a.nombre, va.talla, va.color";

        $stmt = $this->conexion->prepare($sql);
        $stmt->execute(['id' => $id]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
