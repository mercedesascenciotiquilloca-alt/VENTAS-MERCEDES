
<?php
require_once __DIR__ . "/../config/Conexion.php";

class Compra
{
    private $conexion;

    public function __construct()
    {
        $db = new Conexion();
        $this->conexion = $db->conectar();
    }

    public function obtenerDatos()
    {
        $proveedores = $this->conexion->query(
            "SELECT id, nombre FROM proveedores
             WHERE estado = 'Activo' ORDER BY nombre"
        )->fetchAll(PDO::FETCH_ASSOC);

        $variantes = $this->conexion->query(
            "SELECT v.id AS variante_id, a.id AS articulo_id,
                    a.nombre, a.codigo, v.talla, v.color, v.stock
             FROM variantes_articulo v
             INNER JOIN articulos a ON a.id = v.articulo_id
             WHERE a.estado = 'Activo'
             ORDER BY a.nombre, v.talla, v.color"
        )->fetchAll(PDO::FETCH_ASSOC);

        return [
            "proveedores" => $proveedores,
            "variantes" => $variantes
        ];
    }

    public function listar()
    {
        $sql = "SELECT c.id, c.fecha_compra, c.comprobante,
                       c.total, c.estado, p.nombre AS proveedor
                FROM compras c
                INNER JOIN proveedores p ON p.id = c.proveedor_id
                ORDER BY c.id DESC";

        return $this->conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function registrar($proveedorId, $comprobante, $detalles)
    {
        if ($proveedorId <= 0 || !is_array($detalles) || count($detalles) === 0) {
            throw new Exception("Selecciona un proveedor y agrega productos.");
        }

        $this->conexion->beginTransaction();

        try {
            $verificar = $this->conexion->prepare(
                "SELECT id FROM proveedores
                 WHERE id = ? AND estado = 'Activo'"
            );
            $verificar->execute([$proveedorId]);

            if (!$verificar->fetch()) {
                throw new Exception("El proveedor seleccionado no está activo.");
            }

            $total = 0;
            $items = [];

            foreach ($detalles as $detalle) {
                $varianteId = (int)($detalle["variante_id"] ?? 0);
                $cantidad = (int)($detalle["cantidad"] ?? 0);
                $costo = (float)($detalle["costo_unitario"] ?? 0);

                if ($varianteId <= 0 || $cantidad <= 0 || $costo <= 0) {
                    throw new Exception("Revisa las cantidades y los costos de los productos.");
                }

                $consulta = $this->conexion->prepare(
                    "SELECT id FROM variantes_articulo
                     WHERE id = ? FOR UPDATE"
                );
                $consulta->execute([$varianteId]);

                if (!$consulta->fetch()) {
                    throw new Exception("Una de las variantes seleccionadas no existe.");
                }

                $subtotal = round($cantidad * $costo, 2);
                $total += $subtotal;

                $items[] = [
                    "variante_id" => $varianteId,
                    "cantidad" => $cantidad,
                    "costo" => $costo,
                    "subtotal" => $subtotal
                ];
            }

            $insertarCompra = $this->conexion->prepare(
                "INSERT INTO compras (proveedor_id, comprobante, total)
                 VALUES (?, ?, ?)"
            );

            $insertarCompra->execute([
                $proveedorId,
                trim($comprobante) !== "" ? trim($comprobante) : null,
                round($total, 2)
            ]);

            $compraId = (int)$this->conexion->lastInsertId();

            $insertarDetalle = $this->conexion->prepare(
                "INSERT INTO detalle_compras
                 (compra_id, variante_id, cantidad, costo_unitario, subtotal)
                 VALUES (?, ?, ?, ?, ?)"
            );

            $actualizarStock = $this->conexion->prepare(
                "UPDATE variantes_articulo
                 SET stock = stock + ?
                 WHERE id = ?"
            );

            foreach ($items as $item) {
                $insertarDetalle->execute([
                    $compraId,
                    $item["variante_id"],
                    $item["cantidad"],
                    $item["costo"],
                    $item["subtotal"]
                ]);

                $actualizarStock->execute([
                    $item["cantidad"],
                    $item["variante_id"]
                ]);
            }

            $this->conexion->commit();

            return [
                "id" => $compraId,
                "total" => round($total, 2)
            ];

        } catch (Throwable $e) {
            if ($this->conexion->inTransaction()) {
                $this->conexion->rollBack();
            }

            throw $e;
        }
    }
}
